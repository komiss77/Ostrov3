package ru.ostrov77.factions.Enums;

    
    public enum WarEndCause {
        Перемирие, Репарация, Контрибуция, Распался;
    }
    
    