package ru.ostrov77.factions.Enums;

import net.md_5.bungee.api.ChatColor;
import org.bukkit.Material;

    
    public enum LogType {
        //не менять! В мускуле енум!
        Информация (ChatColor.GRAY, Material.WHITE_CARPET),
        Порядок (ChatColor.GREEN, Material.GREEN_CARPET),
        Предупреждение (ChatColor.GOLD, Material.YELLOW_CARPET),
        Ошибка (ChatColor.RED, Material.RED_CARPET),
        ;


        public final ChatColor color;
        public final Material logo;


        private LogType (final ChatColor color, final Material logo) {
            this.color = color;
            this.logo = logo;
        }

        public static LogType fromString(final String type) {
            for (final LogType t : values()) {
                if (t.toString().equalsIgnoreCase(type)) return t;
            }
            return Информация;
        }


    }
