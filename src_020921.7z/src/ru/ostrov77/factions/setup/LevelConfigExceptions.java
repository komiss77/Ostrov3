package ru.ostrov77.factions.setup;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.komiss77.ApiOstrov;
import ru.komiss77.Ostrov;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.ItemUtils;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;
import ru.komiss77.version.AnvilGUI;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.Price;



public class LevelConfigExceptions implements InventoryProvider {


    private static final ItemStack line = new ItemBuilder(Material.ORANGE_STAINED_GLASS_PANE).name("§8.").build();;
    
    public LevelConfigExceptions() {
    }

    
    
    
    
    
    
    @Override
    public void init(final Player player, final InventoryContent contents) {
        player.playSound(player.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 5, 5);
        
        contents.fillRow(4, ClickableItem.empty(line));
        


        

        
        int fromNum = -1;
        int limit = 0;
        
        
        for (final Material mat : Price.getExceptionsList()) {
            fromNum++;
            if (fromNum<Price.editExcPage*36) continue;

            final ItemStack is = new ItemBuilder(mat)
                    //.name("§f"+LanguageHelper.getItemDisplayName(new ItemStack(mat), player))
                    .lore("§7")
                    .lore("§eЗадано значение: §a"+Price.getPrice(mat))
                    .lore("§7")
                    .lore("§7ЛКМ - изменить значение")
                    .lore("§7ПКМ - убрать из исключений")
                    .lore("§7")
                    .build();
//System.out.println(" mat="+mat.toString());

                contents.add(ClickableItem.of(is, e -> {
                        if (e.isLeftClick()) {
                            Price.changed = true;
                            
                            AnvilGUI ag = new AnvilGUI(Ostrov.instance, player, ""+Price.getPrice(mat), (p, value) -> {
                                if (!ApiOstrov.isInteger(value)) {
                                    player.sendMessage("§cДолжно быть число!");
                                    FM.soundDeny(player);
                                    Price.changed = false;
                                    return null;
                                }
                                final int newValue = Integer.valueOf(value);
                                if (newValue<0 || newValue>10000) {
                                    player.sendMessage("§cот 0 до 10000");
                                    FM.soundDeny(player);
                                    return null;
                                }
                                if (Price.getPrice(mat)==newValue) {
                                    Price.changed = false;
                                } else {
                                    Price.addExceptions(mat,newValue);
                                }
                                reopen(player, contents);
                                return null;
                            });
                            
                        } else if (e.isRightClick()) {
                            Price.removeExceptions(mat);
                            Price.getPrice(mat);
                            Price.changed = true;
                            reopen(player, contents);
                        } else {
                            FM.soundDeny(player);
                        }
                        
                    }
                ));

                
                limit++;
                if (limit>=36) break;

        }


                
                
                
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        //if (!pagination.isLast()) {
        if (Price.editExcPage>0) {
            contents.set(4, 0, ClickableItem.of(ItemUtils.previosPage, e -> {
                Price.editExcPage--;
                reopen(player, contents);
            }
            ));
        }
        
        if (Price.getExceptionsSize()> (Price.editExcPage+1)*36) {
            contents.set(4, 8, ClickableItem.of(ItemUtils.nextPage, e -> {
                Price.editExcPage++;
                reopen(player, contents);
            }
            ));
        }

        
        
        
        
        
        
        
        
        
        
        

        contents.set(5, 0, ClickableItem.empty(new ItemBuilder(Material.FLOWER_BANNER_PATTERN)
            .name("§7Помощь")
            .lore("§7Здесь показаны фиксированные значения")
            .lore("§7для блоков, исключённых из общего списка.")
            .lore("§7")
            .lore("§7После удаления из списка")
            .lore("§7блок вернётся в общий список.")
            .lore("§7")
            .lore("§7")
            .build()));
          
        
        

        contents.set( 5, 4, ClickableItem.of( new ItemBuilder(Material.OAK_DOOR).name("назад").build(), e 
                -> SetupManager.openPriceConfigMenu(player)
        ));
        
        

        

        

    }
    
    
        
}
