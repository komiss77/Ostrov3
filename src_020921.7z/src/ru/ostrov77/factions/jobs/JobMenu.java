package ru.ostrov77.factions.jobs;


import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.objects.Fplayer;




public class JobMenu implements InventoryProvider {
    
    

    public JobMenu() {
    }
    
    private static final ItemStack fill = new ItemBuilder(Material.DEAD_FIRE_CORAL).name("§8.").build();;
    
    
    @Override
    public void init(final Player p, final InventoryContent contents) {

        contents.fillBorders(ClickableItem.empty(fill));
        
        
        
        final Fplayer fp = FM.getFplayer(p);

        //меню открывается для всех!
        if (fp.getFaction()==null) {
            int stars = 0;
            for (ItemStack is:p.getInventory().getContents()) {
                if (is!=null && is.getType()==Material.NETHER_STAR) {
                    stars+=is.getAmount();
                }
            }
            contents.set (0,4, ClickableItem.empty(new ItemBuilder(Material.NETHER_STAR)
                .name("У вас "+stars+" крац")
                    .lore("§7(в инвентаре)")
                    .lore("")
                    .lore("§7Для дикаря")
                    .lore("§7доход выдаётся")
                    .lore("§7натурой.")
                    .lore("")
                .build()
            ));
        } else {
            contents.set (0,4, ClickableItem.empty(new ItemBuilder(Material.NETHER_STAR)
                .name("У вас "+fp.getFaction().getUserData(p.getName()).getStars()+" крац")
                    .lore("§7(на счёте клана)")
                    .lore("")
                    .lore("§7Для члена клана")
                    .lore("§7доход зачисляется")
                    .lore("§7на счёт.")
                    .lore("")
                .build()
            ));
        }
        
        
        for (final Job job : Job.values()) {
            
            if (fp.job == job) {
                
                contents.add( ClickableItem.of(new ItemBuilder(job.displayMat)
                    .name("§a"+job)
                    .unsaveEnchantment(Enchantment.LUCK, 1)
                    .addFlags(ItemFlag.HIDE_ATTRIBUTES)
                    .lore("§7")
                    .lore("§aСейчас выбрано!")
                    .lore("")
                    .lore("§6Добыто: §b"+fp.jobCount)
                    .lore("§6До награды: §b"+(job.ammount-fp.jobCount))
                    .lore("")
                    .lore("§5Подработок действует")
                    .lore("§5до выхода с сервера.")
                    .lore("")
                    .lore("§7ПКМ - §4уволиться")
                    .lore("§7")
                    .build(), e -> {
                        if (e.isRightClick()) {
                            fp.job=null;
                            fp.jobCount=0;
                            p.sendMessage("§6Вы больше не на подработках.");
                            p.playSound(p.getLocation(), Sound.BLOCK_LODESTONE_PLACE, 1, 1);
                            reopen(p, contents);
                        }
                    }));     
                
            } else {
                
                contents.add( ClickableItem.of(new ItemBuilder(job.displayMat)
                    .name("§f"+job)
                    .lore("§7")
                    .lore("§b"+job.facture)
                    .lore("§6и получай §b1 §6крац")
                    .lore("§6за каждые §b"+job.ammount+" §6ед.")
                    .lore("§6выполненного.")
                    .lore("§7")
                    .lore("§5Подработок действует")
                    .lore("§5до выхода с сервера.")
                    .lore("§7")
                    .lore("§7ЛКМ - §2устроиться")
                    .lore("§7")
                    .build(), e -> {
                        if (e.isLeftClick()) {
                            fp.job=job;
                            fp.jobCount=0;
                            p.sendMessage("§6Вы устроились на подработку "+job);
                            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1, 1);
                            reopen(p, contents);
                        }
                    }));   
                
            }
            
            
        }
        


        
        

    }
    
    
    
    
    
    
    
    
    
    
}
