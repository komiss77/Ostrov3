package ru.ostrov77.factions.jobs;

import org.bukkit.Material;




    /*
    Лесопилка - Добывай дерево и получай крац. За 15 ед. награждается 0.1 крац
    Угольная шахта - Добывай уголь и получай крац. За 25 ед. награждается 1.2 крац
    Каменоломня - Добывай камень и получай крац.  За 30 ед. награждается 0.2 крац
    Подземельная шахта - Добывай незерак и получай крац.  За 150 ед. награждается 0.1 крац
    Золотая воронка - Добывай золото и получай крац. За 10 ед. награждается 5 крац
    Алмазная воронка - Добывай алмазы и получай крац. За 25 ед. награждается 6 крац
    Ферма - Добывай мясо и получай крац. За 100 ед. награждается 20 крац
    */
    
//PlayerShearEntityEvent

public enum Job {
    //Кузнец (Material.ANVIL, "", 3), 
    Чародей (Material.ENCHANTING_TABLE, "Зачаровывай предметы", 5 ), 
    Каменщик (Material.STONE, "Выплавляй камень", 60 ), 
    //Формовщик (Material.NETHER_BRICK, "Незеритовый кирпич", 850 ), 
    Фермер (Material.WHEAT, "Собирай созревшую пшеницу", 30 ), 
    Старатель (Material.GOLD_ORE, "Добывай золотые слитки", 10 ), //1 крац за 6 слитков 
    Рыбак (Material.FISHING_ROD, "Лови рыбу", 15 ), 
    //Санитар (Material.ZOMBIE_HEAD, "Убивай монстров", 5 ), 
    Горщик (Material.QUARTZ, "Добывай кварц", 100 ), 
    Охотник (Material.BEEF, "Добывай мясо", 12 ), 
    ;
    
    public final Material displayMat;
    public final String facture;
    public final int ammount;
    
    private Job (final Material displayMat,final String facture, final int ammount) {
        this.displayMat = displayMat;
        this.facture = facture;
        this.ammount = ammount;
    }
}
