
package ru.ostrov77.factions.jobs;

import org.bukkit.Material;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.FurnaceExtractEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import ru.komiss77.ApiOstrov;
import ru.komiss77.version.IEntityGroup;
import ru.komiss77.version.VM;
import ru.ostrov77.factions.DbEngine;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.objects.Fplayer;
import ru.ostrov77.factions.objects.UserData;





public class JobListener implements Listener {
   
    @EventHandler
    (priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill (final EntityDeathEvent e) {
        if (e.getEntity().getKiller()!=null && e.getEntity().getKiller().getType()==EntityType.PLAYER) {
            final Player p = e.getEntity().getKiller();
            final Fplayer fp = FM.getFplayer(p);
            if (p==null || fp==null) return;
            
           /* if (VM.getNmsEntitygroup().getEntytyGroup(e.getEntityType())==IEntityGroup.EntityGroup.MONSTER) {
                if (fp.job==Job.Санитар) {
                    fp.jobCount++;
                    checkReward(p, fp);
                } else if (!fp.jobSuggest && fp.job==null) {
                    p.sendMessage("§6Устройтесь на подработку "+Job.Санитар+", и получайте крац за убийство монстров!");
                    fp.jobSuggest=true;
                    //return;
                }
                
            } else */
                if (VM.getNmsEntitygroup().getEntytyGroup(e.getEntityType())==IEntityGroup.EntityGroup.CREATURE) {
                if (fp.job==Job.Охотник) {
                    fp.jobCount++;
                    checkReward(p, fp);
                } else if (!fp.jobSuggest && fp.job==null) {
                    p.sendMessage("§6Устройтесь на подработку "+Job.Охотник+", и получайте крац за добычу мяса!");
                    fp.jobSuggest=true;
                    //return;
                }
            }
        }
    }
    
    
    @EventHandler
    (priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFurnace (final FurnaceExtractEvent e) {
        final Player p = e.getPlayer();
        final Fplayer fp = FM.getFplayer(p);
        if (fp==null) return;
//System.out.println("FurnaceExtractEvent "+e.getItemType()+" action="+e.getItemAmount());        
        

        switch (e.getItemType()) {
            case GOLD_INGOT:
                if (fp.job==Job.Старатель) {
                    fp.jobCount+=e.getItemAmount();
                    checkReward(p,fp);
                } else if (!fp.jobSuggest && fp.job==null) {
                    p.sendMessage("§6Устройтесь на подработку "+Job.Старатель+", и получайте крац за переплавку золота!");
                    fp.jobSuggest=true;
                }
                return;
                
            /*case NETHER_BRICK:
                if (fp.job==Job.Формовщик) {
                    fp.jobCount+=e.getItemAmount();
                    checkReward(p,fp);
                } else if (!fp.jobSuggest && fp.job==null) {
                    p.sendMessage("§6Устройтесь на подработку "+Job.Формовщик+", и получайте крац за выработку адского кирпича!");
                    fp.jobSuggest=true;
                }
                return;*/
                
            case STONE:
                if (fp.job==Job.Каменщик) {
                    fp.jobCount+=e.getItemAmount();
                    checkReward(p,fp);
                } else if (!fp.jobSuggest && fp.job==null) {
                    p.sendMessage("§6Устройтесь на подработку "+Job.Каменщик+", и получайте крац за выработку камня!");
                    fp.jobSuggest=true;
                }
                return;
                
        }
        
    }
        
    
    @EventHandler
    (priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish (final PlayerFishEvent e) {
        final Player p = e.getPlayer();
        final Fplayer fp = FM.getFplayer(p);
        if (fp==null) return;

        if (e.getCaught()!=null) {
            if (fp.job==Job.Рыбак) {
                fp.jobCount++;
                checkReward(p, fp);
            } else if (!fp.jobSuggest && fp.job==null) {
                p.sendMessage("§6Устройтесь на подработку "+Job.Рыбак+", и получайте крац за ловлю рыбы!");
                fp.jobSuggest=true;
                //return;
            }

        }
    }
    
    
    
    @EventHandler
    (priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEnchant (final EnchantItemEvent e) {
        final Player p = e.getEnchanter();
        final Fplayer fp = FM.getFplayer(p);
        if (fp==null) return;
//System.out.println("onEnchant "+e.getItem());
        //if (e.getItem()!=null) {
            if (fp.job==Job.Чародей) {
                fp.jobCount++;
                checkReward(p, fp);
            } else if (!fp.jobSuggest && fp.job==null) {
                p.sendMessage("§6Устройтесь на подработку "+Job.Чародей+", и получайте крац зачаровывая предметы!");
                fp.jobSuggest=true;
                //return;
            }

        //}
    }
    
    @EventHandler
    (priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMine (final BlockBreakEvent e) {
        final Player p = e.getPlayer();
        final Fplayer fp = FM.getFplayer(p);
        if (fp==null) return;
//System.out.println("onMine "+e.getBlock().getType());
        //if (e.getItem()!=null) {
            if (e.getBlock().getType()==Material.NETHER_QUARTZ_ORE) {
                if (fp.job==Job.Горщик) {
                    fp.jobCount++;
                    checkReward(p, fp);
                } else {
                    p.sendMessage("§6Устройтесь на подработку "+Job.Горщик+", и получайте награду, добывая кварц!");
                    fp.jobSuggest=true;
                }
            } else if (e.getBlock().getType()==Material.WHEAT) {
                //BlockData bd = Material.WHEAT.createBlockData();
//System.out.println("age="+age.getAge()+" max="+age.getMaximumAge());
                if ( fp.job==Job.Фермер) {
                    Ageable age = (Ageable) e.getBlock().getBlockData();
                    if ( age.getAge()==age.getMaximumAge() ) {
                        fp.jobCount++;
                        checkReward(p, fp);
                    }
                } else if (!fp.jobSuggest && fp.job==null) {
                    p.sendMessage("§6Устройтесь на подработку "+Job.Фермер+", и получайте награду, собирая созревшую пшеницу!");
                    fp.jobSuggest=true;
                    //return;
                }

        }
    }
    
    
  /*  @EventHandler
    (priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSmith (final SmithItemEvent e) {
        final Player p = e.getEnchanter();
        final Fplayer fp = FM.getFplayer(p);
        if (fp==null) return;
System.out.println("onSmith "+e.getItem());

        if (e.getCaught()!=null) {
            if (fp.job==Job.Кузнец) {
                fp.jobCount++;
                checkReward(p, fp);
            } else if (!fp.jobSuggest && fp.job==null) {
                p.sendMessage("§6Устройтесь на подработку "+Job.Кузнец+", и получайте крац за кузнечное дело!");
                fp.jobSuggest=true;
                //return;
            }

        }
    }*/
    
    
    

    

















    
    
    
    
    

    private void checkReward(final Player p, final Fplayer fp) {
        if (fp.jobCount>=fp.job.ammount) {
            final int full = (int) Math.floor(fp.jobCount/fp.job.ammount);
            fp.jobCount=fp.jobCount - full*fp.job.ammount;
            
            ApiOstrov.sendActionBarDirect(p, "§bПодработок принёс Вам "+full+" крац");
            
            if (fp.getFaction()==null) {
                final Item item = p.getWorld().dropItemNaturally(p.getLocation().clone().add(0, 0.3, 0), new ItemStack(Material.NETHER_STAR, full));
                item.setGlowing(true);
                item.setGravity(false);
                item.setPickupDelay(40);
                item.setVelocity(new Vector(0, 0, 0));
//System.out.println("dropItemNaturally "+item);
            } else {
                final UserData ud = fp.getFaction().getUserData(fp.name);
                ud.setStars(ud.getStars()+full);
                DbEngine.saveUserData(fp.name, ud);
            }
            
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
