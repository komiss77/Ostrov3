package ru.ostrov77.factions.objects;

import java.util.HashSet;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Bat;
import org.bukkit.entity.Player;
import ru.komiss77.ApiOstrov;
import ru.komiss77.scoreboard.CustomScore;
import ru.ostrov77.factions.DbEngine;
import ru.ostrov77.factions.Enums.Perm;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.Land;
import ru.ostrov77.factions.Main;
import ru.ostrov77.factions.ScoreMaps;
import ru.ostrov77.factions.ScoreMaps.ScoreMode;
import ru.ostrov77.factions.jobs.Job;
import ru.ostrov77.factions.listener.ChatListen;
import ru.ostrov77.factions.listener.ChatListen.ChatType;







public class Fplayer {
    
    //статика
    public final String name;
    public CustomScore score;
    private int factionId = 0; //0-нет клана
    
    //сохраняемые
    public ChatType chatType = ChatType.Локальный;
    private ScoreMode scoreMode = ScoreMode.None; //при  выборе none сбросить!
    public int mapSize = 7;
    public boolean mapFix = false;
    public boolean territoryInfoTitles = true;
    public boolean autoClaimFaction = false;
    //public int power = 0;
    
    //динамические
    public long onlineSec = 0;
    public Set<Integer> invites = new HashSet<>();
    public Location delayTpLocation = null;
    public int lastMoveInFactionId = 0; //ид клана
    public int lastMoveCloc; //cLoc
    public BlockFace lastDirection = BlockFace.DOWN;
    public String lastHit=""; 
    public int lastHitFactionId;
    public int lastHitTime=0; //Timer.currentTimeSec последнего удара от кого-то
    private long lastInteractStamp = System.currentTimeMillis();
    public int psionAtack; //секунды псионной атаки
    public Bat bat;
    public Job job;
    public int jobCount;
    public boolean jobSuggest;

    public Fplayer(final Player p) {
        this.name = p.getName();
        lastMoveCloc = Land.getcLoc(p.getLocation());
        score = new CustomScore(p);
    }

    public Fplayer(final Player p, final Faction f) {
        this.name = p.getName();
        factionId = f.factionId;
        lastMoveCloc = Land.getcLoc(p.getLocation());
        score = new CustomScore(p);
        fromString(f.getUserData(name).getSettings());
    }
    
    public void joinFaction(final Faction f) {
        factionId = f.factionId;
        chatType = ChatType.Клан;
        setScoreMode(ScoreMode.MiniMap); 
    }
    
    public void reset() {
        factionId = 0;
        chatType = ChatType.Локальный;
        setScoreMode(ScoreMode.None); 
        //joinedAt = 0;
        score.getSideBar().reset();
        lastDirection = BlockFace.DOWN;
        mapSize = 7;
        mapFix = false;
        invites.clear();
        delayTpLocation = null;
        //power = 0;
        //save(true, false);
    }
    
    
    
    
    
    
    
    private void fromString(final String settings) {
        final String[]split = settings.split(",");
        if (split.length>=1) chatType = ChatType.fromString(split[0]);
        if (split.length>=2) scoreMode = ScoreMode.fromString(split[1]);
        if (split.length>=3 && ApiOstrov.isInteger(split[2])) mapSize = Integer.parseInt(split[2]);
        if (split.length>=4 && split[3].trim().equals("1")) mapFix = true;
        if (split.length>=5 && split[4].trim().equals("0")) territoryInfoTitles = false;
        if (split.length>=6 && split[5].trim().equals("1")) autoClaimFaction = true;
        //if (split.length>=7 && ApiOstrov.isInteger(split[6])) power = Integer.parseInt(split[6]);
        //if (split.length>=8 && ApiOstrov.isInteger(split[7])) stars = Integer.parseInt(split[7]);
        
        
        Main.sync(()-> {
            setScoreMode(scoreMode);
            //switch (scoreMode==) {
                //case MiniMap:
                    //score.getSideBar().setTitle("§7Терриконы   ");
                    //ScoreMaps.updateMap(this);
                    //break;
            //}
            ChatListen.setChatType(this, chatType);
        }, 2); //0 не катит - Player может быть ещё не создан!!
        
    }

    public String asString() {
        StringBuilder sb = new StringBuilder("");
        
        sb.append(chatType.toString()).append(",");
        sb.append(scoreMode.toString()).append(",");
        sb.append(mapSize).append(",");
        sb.append(mapFix ? "1" : "0").append(",");
        sb.append(territoryInfoTitles ? "1" : "0").append(",");
        sb.append(autoClaimFaction ? "1" : "0").append(",");
        //sb.append(power).append(",");
        //sb.append(stars).append(",");

        return sb.toString();
    }


    public Player getPlayer() {
        return Bukkit.getPlayer(name);
    }

    //public Faction getFaction() {
    //    return FM.getPlayerFaction(name);
    //}

    public void save(final boolean async, final boolean delete) {
        DbEngine.saveFplayerData(this, async, delete);
        storeUserData();
    }
    public void save() { //простое async сохранение
        DbEngine.saveFplayerData(this, true, false);
        storeUserData();
    }
    private void storeUserData() {
        if (factionId!=0) {
            final Faction f = FM.getFaction(factionId);
            if (f!=null && f.isMember(name)) {
                f.getUserData(name).setSettings(asString());
            }
        }
    }


    public int getFactionId() {
        return factionId;
    }

    public ScoreMode getScoreMode() {
        return scoreMode;
    }

    public void setScoreMode(final ScoreMode mode) {
        scoreMode = mode;
        switch (mode) {
            case MiniMap: 
                score.getSideBar().setTitle("§7Терриконы   ");
                ScoreMaps.updateMap(this);
                break;
            case Score: 
                score.getSideBar().setTitle("§fКлан"); 
                break;
            case Turrets: 
                score.getSideBar().setTitle("§fТурели"); 
                break;
            case None: 
                score.getSideBar().setTitle(""); 
                break;
        }
    }

    public Faction getFaction() {
        return FM.getFaction(factionId);
    }

    public boolean interactDelay() {
//System.out.println("interactDelay d="+(System.currentTimeMillis()-lastInteractStamp) + " can?"+(System.currentTimeMillis()-lastInteractStamp>=249));
        if (System.currentTimeMillis()-lastInteractStamp>=249) { //1000=1 сек.
            //updateActivity();
            return false;
        }
        return true;
    }

    public void updateActivity() {
//System.out.println("updateActivity");
        lastInteractStamp = System.currentTimeMillis();
    }

    public boolean isAfk() {
        return System.currentTimeMillis()-lastInteractStamp > 900000; //1000=1 сек. 60.000=1мин 900,000=15мин
    }

    public boolean hasPerm(final Perm perm) {
        return getFaction()!=null && getFaction().hasPerm(name, perm);
    }
    
    
    
}
