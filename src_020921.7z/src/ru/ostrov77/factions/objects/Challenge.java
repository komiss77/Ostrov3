package ru.ostrov77.factions.objects;

import com.meowj.langutils.lang.LanguageHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import ru.komiss77.utils.ItemUtils;



//требования: 1.предметы инвентарь, 2.животные в мире, 3.блоки в радиусе, 4.другие задания, 5.уровень
//задание можно выполнить х раз, после чего оно (has hext?) "станет неактивным" : "заменится на х"

public class Challenge {

     
    //требования
    public HashMap<Material,Integer> requiredItems = new HashMap<>();
    public boolean takeItems = true;
    public HashMap<Material,Integer> requiredBlock = new HashMap<>();
    public int checkRadius = 20;
    public HashMap<EntityType,Integer> requiredEntities = new HashMap<>();
    public boolean takeEntity = false;
    public final List <String> requestInfo = new ArrayList<>();
    public List <String> rewardInfo;
    
    //награда
    //public String rewardTxt="";

    
    public Challenge() {
    }
    


    public List<String> getRequestInfo() {
        return requestInfo;
    }
    public List<String> getRewardInfo() {
        return rewardInfo;
    }

    public void genLore() {
        //lore.add("§5---- Требования ----");
        
            final int limit = 4;
            int ammount;
            int count;
            
        //предметы
            count = limit;
            for (final Material mat : requiredItems.keySet()) {
                ammount = requiredItems.get(mat);
                requestInfo.add( (count==limit?"§fПредметы: "+(requiredItems.isEmpty()?"§7---":"") : "") 
                        + "§6"+LanguageHelper.getMaterialName(mat, "RU_ru") 
                        + (ammount==1?"":"§7:§b"+ammount) 
                        + (count==1 && requiredItems.size()>limit ? " §e.. и еще "+(requiredItems.size()-limit):"") );
                if (count==1) break;
                count--;
            }
            
        //животные
            count = limit;
            for (final EntityType r : requiredEntities.keySet()) {
                ammount = requiredEntities.get(r);
                requestInfo.add( (count==limit?"§fЖивотные: "+(requiredEntities.isEmpty()?"§7---":"") : "") 
                        + "§6"+LanguageHelper.getEntityName(r, "RU_ru") 
                        + (ammount==1?"":"§7:§b"+ammount) 
                        + (count==1 && requiredEntities.size()>limit ? " §e.. и еще "+(requiredEntities.size()-limit):"") );
                if (count==1) break;
                count--;
            }
            
            if (takeItems || takeEntity) {
                requestInfo.add( (takeItems ? "§eпредметы":"") + (takeItems && takeEntity?" и ":"") + (takeEntity ? "§eживотные":"") +" будут забраны!");
            }

        //блоки в радиусе
            count = limit;
            for (final Material r : requiredBlock.keySet()) {
                ammount = requiredBlock.get(r);
                requestInfo.add( (count==limit?"§fБлоки в радиусе "+checkRadius+"м.: "+(requiredBlock.isEmpty()?"§7---":"") : "") 
                        + "§6"+LanguageHelper.getMaterialName(r, "RU_ru") 
                        + (ammount==1?"":"§7:§b"+ammount) 
                        + (count==1 && requiredBlock.size()>limit ? " §e.. и еще "+(requiredBlock.size()-limit):"") );
                if (count==1) break;
                count--;
            }
            
            
        
        
        

        requestInfo.add("§5--------------------");
        requestInfo.add("");
    }

    public void setRewardInfo(final String info) {
        rewardInfo = ItemUtils.Gen_lore(null, info, "§3");
    }

   
}
