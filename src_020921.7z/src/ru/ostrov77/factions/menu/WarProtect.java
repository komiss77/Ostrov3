package ru.ostrov77.factions.menu;


import net.md_5.bungee.api.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.komiss77.ApiOstrov;
import ru.komiss77.Ostrov;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;
import ru.komiss77.version.AnvilGUI;
import ru.ostrov77.factions.Econ;
import ru.ostrov77.factions.DbEngine.DbField;
import ru.ostrov77.factions.Enums.LogType;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.objects.Faction;
import ru.ostrov77.factions.Relations;
import ru.ostrov77.factions.Enums.Relation;




public class WarProtect implements InventoryProvider {
    
    
    
    private final Faction f;
    private static final ItemStack fill = new ItemBuilder(Material.WHITE_STAINED_GLASS_PANE).name("§8.").build();;
    

    
    public WarProtect(final Faction f) {
        this.f = f;
    }
    
    
    
    @Override
    public void init(final Player p, final InventoryContent contents) {
        p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 5, 5);
        //contents.fillRow(1, ClickableItem.empty(WarProtect.fill));
        
        
        boolean can = true;
        //0
        if (f.getDiplomatyLevel()<2) {
            can=false;
            contents.add(ClickableItem.empty(new ItemBuilder( Material.BARRIER )
                .name("§cУсловие не выполнено!")
                .lore("")
                .lore("§cДля выкупа покровительства требуется")
                .lore("§cдипломатия 2 уровня или выше!")
                .lore("")
                .build()));
            //p.sendMessage("§cДля выкупа покровительства требуется дипломатия 2 уровня или выше!");
            //return;
        }
        
        //1 барьер если недавно воевал
        if (FM.getTime() - f.getLastWarEndTimestamp() < 3*24*60*60) {
            can=false;
            contents.add(ClickableItem.empty(new ItemBuilder( Material.BARRIER )
                .name("§cУсловие не выполнено!")
                .lore("")
                .lore("§cПосле окончания последней войны")
                .lore("§cдолжно пройти более")
                .lore(ChatColor.YELLOW + Econ.housrToTime(3*24))
                .lore("")
                .build()));
            //p.sendMessage("§cДля выкупа покровительства требуется дипломатия 2 уровня или выше!");
            //return;
        }
        
        //2 не должно быть союзов и переговоров о союзе
        int count = Relations.count(f,Relation.Война);
        if (count>0) {
            can=false;
            contents.add(ClickableItem.empty(new ItemBuilder( Material.BARRIER )
                .name("§cУсловие не выполнено!")
                .lore("")
                .lore("§cУ вас не должно быть")
                .lore("§cактивных войн!")
                .lore("§cСейчас их: "+count)
                .lore("")
                .build()));
        }
        //3 не должно быть союзов и переговоров о союзе
        count = Relations.count(f,Relation.Союз);
        if (count>0) {
            can=false;
            contents.add(ClickableItem.empty(new ItemBuilder( Material.BARRIER )
                .name("§cУсловие не выполнено!")
                .lore("")
                .lore("§cУ вас не должно быть")
                .lore("§cсоюзнеческих обязательств!")
                .lore("§cСейчас их: "+count)
                .lore("")
                .build()));
        }
        
        //4
        count = Relations.wishCount(f, Relation.Союз);
        if (count>0) {
            can=false;
            contents.add(ClickableItem.empty(new ItemBuilder( Material.BARRIER )
                .name("§cУсловие не выполнено!")
                .lore("")
                .lore("§cУ вас не должно быть предложений")
                .lore("§cзаключить союз!")
                .lore("§cСейчас их: "+count)
                .lore("")
                .build()));
        }
        
        
        
        // если есть - предложить отказ от покровительства
        //if (f.data.warProtect>0) {
        final boolean can1=can;
        contents.set(0,6, ClickableItem.of(new ItemBuilder( Material.SHIELD )
            .name("§fПокровительство")
            .lore("")
            .lore(f.hasWarProtect() ? "§aДействует еще "+Econ.housrToTime(f.getWarProtect()):"§eНе действует.")
            .lore(f.hasWarProtect() ? "§7Шифт+ПКМ - §cотказаться" : "")
            .lore("")
            .lore( can ? "§7ЛКМ - §a" + (f.hasWarProtect()?"добавить время":"купить покровительство") :"§cВыполните условия")
            .lore( can ? "§b1 крац §7за §f1 час" : "§cдля покупки покровительства!")
            .lore("")
            .build(), e -> {

            switch (e.getClick()) {

                case LEFT:
                    if (!can1) break;
                    final AnvilGUI agui = new AnvilGUI(Ostrov.instance, p, "10", (player, value) -> {
                        if (!ApiOstrov.isInteger(value)) {
                            player.sendMessage("§cДолжно быть число!");
                            FM.soundDeny(player);
                            return null;
                        }
                        final int amount = Integer.valueOf(value);
                        if (amount<1 || amount>1000) {
                            player.sendMessage("§cот 1 до 1000");
                            FM.soundDeny(player);
                            return null;
                        }
                        if (amount>f.econ.stars) {
                            player.sendMessage("§cУ вас нет столько Крац!");
                            FM.soundDeny(player);
                            return null;
                        }
                        f.econ.stars-=amount;
                        f.setWarProtect(f.getWarProtect()+amount);
                        f.save(DbField.econ);
                        f.save(DbField.data);
                        f.broadcastActionBar( "§aДля вашего клана действует покровительство на "+Econ.housrToTime(f.getWarProtect()));
                        f.log(LogType.Порядок,"§aДля вашего клана действует покровительство на "+Econ.housrToTime(f.getWarProtect()));
                        reopen(player, contents);
                        return null;
                    });
                    return;
                    
                case SHIFT_RIGHT:
                    if (!f.hasWarProtect()) break;
                    f.setWarProtect(0);// = 0;
                    f.save(DbField.data);
                    f.broadcastMsg("§eВаш клан добровольно отказался от покровительства!");
                    f.log(LogType.Предупреждение, "§eВаш клан добровольно отказался от покровительства!");
                    reopen(p, contents);
                    return;

            }

            FM.soundDeny(p);

            }));            
        //}



        //показать варианты покупки
        
        
        
        

                
                
                











        

        
        
        contents.set( 0, 8, ClickableItem.of( new ItemBuilder(Material.OAK_DOOR).name("назад").build(), e -> 
            MenuManager.openMainMenu(p)
        ));
        


        
        

    }
    
    
    
    
    
    
    
    
    
    
}
