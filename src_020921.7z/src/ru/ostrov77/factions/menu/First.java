package ru.ostrov77.factions.menu;


import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;
import ru.komiss77.ApiOstrov;
import ru.komiss77.Timer;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.ItemUtils;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;
import ru.komiss77.utils.inventory.SmartInventory;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.Land;
import ru.ostrov77.factions.objects.Faction;
import ru.ostrov77.factions.objects.Fplayer;
import ru.ostrov77.factions.Main;
import ru.ostrov77.factions.Structures;




public class First implements InventoryProvider {
    
    
    
    private static final ItemStack fill = new ItemBuilder(Material.YELLOW_STAINED_GLASS_PANE).name("§8.").build();;
    

    
    public First() {
    }
    
    
    
    @Override
    public void init(final Player p, final InventoryContent contents) {
        p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 5, 5);
        contents.fillBorders(ClickableItem.empty(First.fill));
        
        
        
        final Fplayer fp = FM.getFplayer(p);

        //меню открывается, только если нет клана!
        
        
        contents.set(0, 4, ClickableItem.of( new ItemBuilder(Material.SUNFLOWER)
            .name("§eИнформация")
            .lore("")
            .lore("§7ЛКМ - §eПантеон славы")
            .lore("§7ПКМ - §7ПКМ - §6История войн")
            .lore("§7ШифтЛКМ - §cПадшие")
            .lore("")
            .build(), e -> {
                
                switch (e.getClick()) {
                    case LEFT:
                        p.performCommand("f top");//MenuManager.openTop(p, MenuManager.TopType.claims);
                        return;
                    
                    case RIGHT:
                        p.performCommand("f topwar");//MenuManager.openTopWar(p, MenuManager.TopWarType.kills);
                        return;
                    
                    case SHIFT_LEFT:
                        p.performCommand("f disbaned");//MenuManager.openDisbanned(p, 0);
                        return;
                    
                    case  SHIFT_RIGHT:
                        return;
                }

            }));    





        
        final Faction inThisLoc = Land.getFaction(p.getLocation());
        final boolean toClose = Land.hasSurroundClaim(p.getLocation(), null, 10);
        final String canBuildBase = Structures.canBuild(p);
        /*Claim c;
        for (int x_ = -10; x_<=10; x_++) {
            for (int z_ = -10; z_<=10; z_++) {
                c = Land.getClaim(p.getWorld().getName(), p.getLocation().getChunk().getX()+x_, p.getLocation().getChunk().getZ()+z_);
                if (c!=null) {
                    //FM.soundDeny(p);
                    //p.sendMessage("При создании нового клана, до земель другого клана минимум 10 чанков!");
                    toClose=true;
                    break;
                }
            }
        }*/
            
            contents.set(1, 1, ClickableItem.of( new ItemBuilder(Material.WHITE_BED)
                .name("§fВернуться на спавн")
                .lore("§7")
                .lore("§7Вы находитесь :")
                .lore(inThisLoc!=null ? "§eЗемли "+inThisLoc.getName() : "§2Дикие Земли")
                .lore("§7")
                //.lore("§7Перейдите на Дикие земли,")
                //.lore("§7чтобы создать свой клан!")
                .lore("§7")
                .build(), e -> {
                    if (e.isLeftClick()) {
                        Main.tpLobby(p);
                        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1, 5);
                    }
                }));  
            
        if ( inThisLoc!=null || 
                Timer.has(p, "create")
                || ItemUtils.getItemCount(p, Material.NETHER_STAR) < Main.createPrice
                || toClose//5 чанков! + поиск ближайшего свободного!
                || !canBuildBase.isEmpty()//тут не встанет база
                ) {  //если на чужой терре (в этом чанке есть клан)
            
            contents.set(1, 2, ClickableItem.of(new ItemBuilder( Material.BARRIER )
                .name( "§cСоздать клан")
                .lore("§7")
                .lore("§eДля создания клана надо:")
                .lore( (inThisLoc==null ? "§2✔ §8Перейти на Дикие земли" : "§cПерейти на Дикие земли"))
                .lore( (!toClose ? "§2✔ §810 чанков до других кланов" : "§c10 чанков до других кланов") )
                .lore( canBuildBase.isEmpty() ? "§2✔ §8место подходит" : "§cместо не подходит :") 
                .lore( canBuildBase) 
                    //5 чанков!
                .lore( (ItemUtils.getItemCount(p, Material.NETHER_STAR) >= Main.createPrice ? "§2✔ §8" : "§c") + "Накопить "+Main.createPrice+" крац (звезд Ада)" )
                .lore( Timer.has(p, "create") ? "§cПодождать "+ApiOstrov.secondToTime(Timer.getLeft(p, "create")):"")
                .lore("§7")
                .lore(toClose ? "§fЛКМ - найти свободное место" : "")
                .lore("§7")
                .build(), e->{
                    if (toClose && e.getClick()==ClickType.LEFT) {
                        p.closeInventory();
                        p.performCommand("f findPlace");//Land.findFreePlace(p);
                    }
                }));  
            
        } else { //свободная терра
            
            contents.set(1, 2, ClickableItem.of( new ItemBuilder(inThisLoc!=null ? Material.BARRIER : Material.OAK_SAPLING)
                .name( "§aСоздать свой клан")
                .lore("§7")
                .lore( "§6Цена регистрации: §e"+Main.createPrice+" крац §7(звезда Ада)")
                .lore("§7")
                .lore("§7При создании клана вы сразу")
                .lore("§7получите во владение террикон (чанк),")
                .lore("§7в котором сейчас находитесь.")
                .lore("§7Расширять клан вы сможете")
                .lore("§7только на прилегающие терриконы.")
                .lore("§7Поэтому хорошо подумайте,")
                .lore("§7подходит ли Вам эта местность.")
                .lore("§7Если не подходит, найдите другой")
                .lore("§7свободный террикон, и создайте")
                .lore("§7клан там.")
                .lore("§7")
                .lore("§aЛКМ §7- создать клан")
                .lore("§7")
                .build(), e -> {
                    if (e.isLeftClick()  && (!Timer.has(p, "create") || ApiOstrov.isLocalBuilder(p, false)) ) {
                        p.closeInventory();
                        Main.sync( ()->{ FM.createFaction(p); }, 1);
                        //FM.createFaction(p);
                        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1, 5);
                    }
                }));   
            
        }
        
        
        
        //список кланов 
            
        contents.set(1, 4, ClickableItem.of( new ItemBuilder(Material.BELL)
            .name("§fПРИМИТЕ НОВИЧКА!")
            .lore("§7")
            .lore("§7Оповестить кланы о свободном игроке.")
            .lore(Timer.has(p, "bell")? "§cСможете оповестить через "+ApiOstrov.secondToTime(Timer.getLeft(p, "bell")) : "§aЛКМ §7- оповестить")
            .lore("§7")
            .build(), e -> {
                if (e.isLeftClick() && !Timer.has(p, "bell")) {
                    Timer.add(p, "bell", 300);
                    FM.getFactions().stream().filter( (f) -> (f.isOnline()) ).forEach( 
                            (f) -> {f.broadcastMsg("§6Дикарь §f"+p.getName()+" §6желает вступить в клан!"); }
                    );
                    p.playSound(p.getLocation(), Sound.BLOCK_BELL_USE, 1, 1);
                }
                reopen(p, contents);
            }));    
        

    
        
        
        contents.set(1, 6, ClickableItem.of( new ItemBuilder(Material.CARROT_ON_A_STICK)
            .name("§bПросмотр приглашений")
            .lore("§7")
            .lore("§7Список актуальных приглашений")
            .lore("§7для совместного развития")
            .lore("§7от владельцев островков.")
            .lore("§7")
            .lore(fp.invites.isEmpty() ? "§cприглашений нет." : "§bЛКМ - просмотр §6(§e"+fp.invites.size()+"§6)")
            .lore("§7ПКМ - обновить")
            .lore("§7")
            .build(), e -> {
                if (e.isLeftClick()) {
                    if (!fp.invites.isEmpty()) {
                        MenuManager.openInviteConfirmMenu(p);
                    } else {
                        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASEDRUM, 1, 5);
                    }
                } else if (e.isRightClick()) {
                    p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 1, 5);
                    reopen(p, contents);
                }
            }));         
        

        
        contents.set(1, 7, ClickableItem.of( new ItemBuilder(Material.HONEYCOMB)
            .name("§eПрисоедениться")
            .lore("§7")
            .lore("§7Войти в клан, принимающий всех")
            .lore("§7и не требующий приглашения.")
            .lore("§7")
            .build(), e -> {
                if (e.isLeftClick()) {
                    SmartInventory.builder().id("SelectJoin"+p.getName()). provider(new SelectJoin()). size(6, 9). title("§fВступить в клан").build() .open(p);
                }
            }));    
    

        
        
        
        
        
        
        

    }
    
    
    
    
    
    
    
    
    
    
}
