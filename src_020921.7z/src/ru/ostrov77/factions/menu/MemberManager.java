package ru.ostrov77.factions.menu;


import java.util.ArrayList;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.komiss77.ApiOstrov;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.ItemUtils;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.ConfirmationGUI;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;
import ru.komiss77.utils.inventory.Pagination;
import ru.komiss77.utils.inventory.SlotIterator;
import ru.komiss77.utils.inventory.SlotPos;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.Enums.Role;
import ru.ostrov77.factions.objects.Faction;
import ru.ostrov77.factions.objects.UserData;
import ru.ostrov77.factions.objects.Fplayer;
import ru.ostrov77.factions.Enums.LogType;
import ru.ostrov77.factions.Enums.Perm;




public class MemberManager implements InventoryProvider {
    
    
    
    private final Faction f;
    private static final ItemStack fill = new ItemBuilder(Material.PINK_STAINED_GLASS_PANE).name("§8.").build();;
    

    
    public MemberManager(final Faction f) {
        this.f = f;
    }
    
    
    
    @Override
    public void init(final Player player, final InventoryContent contents) {
        player.playSound(player.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 5, 5);
        contents.fillBorders(ClickableItem.empty(MemberManager.fill));
        final Pagination pagination = contents.pagination();
        final ArrayList<ClickableItem> menuEntry = new ArrayList<>();
        
        //владелец
      /*  menuEntry.add(ClickableItem.empty(new ItemBuilder(Material.PLAYER_HEAD)
            .name("§b"+f.getOwner())
            .lore("§fЛидер")
            .lore("§7")
            .lore("§aМожет всё.")
            .lore("§7")
            .build()
        )); */
        
        
        final UserData currentPerm = f.getUserData(player.getName()); //права текущего 
        
        for (final Role role : Role.values()) { //роли в порядке возрастания, типа сортировка
            //if (role==Enums.Role.Лидер) continue; //лидера пропускаем - идёт первый
        
            for (final String name : f.getMembers()) {

            final UserData  ud = f.getUserData(name);
            final Fplayer fp = FM.getFplayer(name); //-может быть null (оффлайн) !!

                if (ud.getRole()!=role) continue;

                final ItemStack icon = new ItemBuilder(role.displayMat)
                    .name("§f"+name)
                    .lore( name.equalsIgnoreCase(player.getName()) ? "§6это вы" : (f.hasPerm(player.getName(), Perm.ChangePerm) && currentPerm.getRole().order>ud.getRole().order ? "§7ЛКМ - настроить права" : (f.hasPerm(player.getName(), Perm.ChangePerm)?"§cнет прав менять":"§cранг выше вашего") ) )
                    .lore("§7Звание: "+ud.getRole().displayName)
                    .lore(fp==null ? "§dОффлайн" : "§7В клане: "+ApiOstrov.secondToTime((FM.getTime()-ud.joinedAt)))
                    .lore( name.equalsIgnoreCase(player.getName()) ? "" : (f.hasPerm(player.getName(), Perm.Kick) && currentPerm.getRole().order>ud.getRole().order ? "§7Q - выгнать" : "§cвы не можете выгонять") )
                    .lore(currentPerm.getRole().order>=2 && currentPerm.getRole().order-1>ud.getRole().order ? "§7Шифт+ЛКМ - повысить в звании" : "") //рекруты и рядовые точно не могут, и поднять до своего звания нельзя.
                    .lore(ud.getRole().order>=1 && currentPerm.getRole().order>ud.getRole().order ? "§7Шифт+ПКМ - понизить в звании" : "")
                    .lore("§7")
                    .lore("§7")
                    //.lore("§6Права:")
                    /*.lore("§bСтавить стартовую точку: "+(userPerm.canSetSpawnPoint ? "§2Да":"§4Нет"))
                    .lore("§bИзменять права жителей: "+(userPerm.canChangeMemberPermission ? "§2Да":"§4Нет"))
                    .lore("§bВыгонять жителей: "+(userPerm.canKickMember ? "§2Да":"§4Нет"))
                    .lore("§bОткрывать/закрывать для гостей: "+(userPerm.canOpenForGuest ? "§2Да":"§4Нет"))
                    .lore("§bОтправлять приглашения: "+(userPerm.canSendInvite ? "§2Да":"§4Нет"))
                    .lore("§bИзменять приветствие: "+(userPerm.canChangeWelcomeMsg ? "§2Да":"§4Нет"))
                    .lore("§bИзменять прощание: "+(userPerm.canChangeFarewellMsg ? "§2Да":"§4Нет"))
                    .lore("§bВыполнять задания: "+(userPerm.canDoChallenge ? "§2Да":"§4Нет"))
                    .lore("§bПросматривать логи: "+(userPerm.canViewLogs ? "§2Да":"§4Нет"))*/
                    //.lore("§b")
                    .lore("")
                    .build();

                menuEntry.add(ClickableItem.of(icon, e -> {
                    
                    switch (e.getClick()) {
                        
                        case LEFT:
                            if ( !name.equalsIgnoreCase(player.getName()) && f.hasPerm(player.getName(), Perm.ChangePerm) && currentPerm.getRole().order>ud.getRole().order) {
                                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1);
                                MenuManager.openMemberPermMenu(player, f, name);
                                return;
                            }
                            break;
                            
                        case DROP:
                            if ( !name.equalsIgnoreCase(player.getName()) && f.hasPerm(player.getName(), Perm.Kick) && currentPerm.getRole().order>ud.getRole().order ) {
                                ConfirmationGUI.open( player, "§4Выгнать из клана ?", result -> {
                                    if (result) {
                                        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1);
                                        FM.leaveFaction(f, name, "§eВы больше не в клане!");
                                    } else {
                                        player.playSound(player.getLocation(), Sound.ENTITY_LEASH_KNOT_PLACE, 0.5f, 0.85f);
                                    }
                                    reopen(player, contents);
                                });
                                return;
                            }
                            break;
                            
                        case SHIFT_LEFT:
                            if (ud.getRole()==Role.Офицер) {
                                player.sendMessage("§cВыше "+ud.getRole()+" повысить нельзя! Но вы можете передать лидерство в настройках клана.");
                                return;
                            }
                            if (currentPerm.getRole().order>=2 && currentPerm.getRole().order-1>ud.getRole().order) {
                                final Role newRole = Role.fromOrder(ud.getRole().order+1);
                                f.broadcastMsg("§a"+player.getName()+(ApiOstrov.isFemale(player.getName())?" §fповысила ":" §fповысил ")+name+" §fдо звания "+newRole.displayName+" §f!" );
                                f.setRole(name, newRole);//f.addMember(name, new UserData(newRole));
                                //DbEngine.savePlayerDataOffline(name, f);
                                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 2);
                                reopen(player, contents);
                                f.log(LogType.Порядок, "§a"+player.getName()+(ApiOstrov.isFemale(player.getName())?" §fповысила ":" §fповысил ")+name+" §fдо звания "+newRole.displayName+" §f!");
                                return;
                            } else {
                                player.sendMessage("§cВаше звание не позволяет повышать звание дальше "+ud.getRole());
                            }
                            break;
                            
                        case SHIFT_RIGHT:
                            if (ud.getRole().order<=1) {
                                player.sendMessage("§cНет звания ниже "+ud.getRole());
                                return;
                            }
                            if (currentPerm.getRole().order>ud.getRole().order) {
                                final Role newRole = Role.fromOrder(ud.getRole().order-1);
                                f.broadcastMsg("§a"+player.getName()+(ApiOstrov.isFemale(player.getName())?" §fразжаловала ":" §fразжаловал ")+name+" §fдо "+newRole.displayName+" §f!" );
                                f.setRole(name, newRole);//f.users.put(name, new UserData(newRole));
                                //DbEngine.savePlayerDataOffline(name, f);
                                reopen(player, contents);
                                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 2);
                                f.log(LogType.Порядок, "§a"+player.getName()+(ApiOstrov.isFemale(player.getName())?" §fповысила ":" §fповысил ")+name+" §fдо "+newRole.displayName+" §f!");
                                return;
                            } else {
                                player.sendMessage("§cВаше звание не позволяет разжаловать с должности "+ud.getRole());
                            }
                            break;
                            
                        
                            
                    }
                    
                    FM.soundDeny(player);

                }));            
            }
        
        }
    
        

        
        
            
            
        
        
        
        
        
        
        
        
        pagination.setItems(menuEntry.toArray(new ClickableItem[menuEntry.size()]));
        pagination.setItemsPerPage(21);
        

        

        
        
        
        contents.set( 5, 4, ClickableItem.of( new ItemBuilder(Material.OAK_DOOR).name("гл.меню").build(), e -> 
            MenuManager.openMainMenu(player)
        ));
        

        
        if (!pagination.isLast()) {
            contents.set(5, 8, ClickableItem.of(ItemUtils.nextPage, e 
                    -> contents.getHost().open(player, pagination.next().getPage()) )
            );
        }

        if (!pagination.isFirst()) {
            contents.set(5, 0, ClickableItem.of(ItemUtils.previosPage, e 
                    -> contents.getHost().open(player, pagination.previous().getPage()) )
            );
        }
        
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, SlotPos.of(1, 1)).allowOverride(false));
        

        
        

    }
    
    
    
    
    
    
    
    
    
    
}
