package ru.ostrov77.factions.menu;


import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.komiss77.Ostrov;
import ru.komiss77.modules.DelayTeleport;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;
import ru.komiss77.utils.inventory.SmartInventory;
import ru.komiss77.version.AnvilGUI;
import ru.ostrov77.factions.DbEngine;
import ru.ostrov77.factions.Enums.Perm;
import ru.ostrov77.factions.Enums.Science;
import ru.ostrov77.factions.Enums.Structure;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.objects.Faction;
import ru.ostrov77.factions.Land;
import ru.ostrov77.factions.Level;
import ru.ostrov77.factions.Sciences;
import ru.ostrov77.factions.objects.Claim;
import ru.ostrov77.factions.objects.UserData;




public class StructureTeleporter implements InventoryProvider {
    
    
    private final Claim claim;
    //private static final ItemStack fill = new ItemBuilder(Material.LIME_STAINED_GLASS_PANE).name("§8.").build();;

    
    public StructureTeleporter(final Claim claim) {
        this.claim = claim;
    }
    
    
    
    @Override
    public void init(final Player p, final InventoryContent contents) {
        //p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 5, 5);
        //contents.fillRect(0,0, 2,3, ClickableItem.empty(fill1));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GUARDIAN_DEATH, 0.3f, 1);
        
        if (claim==null || !claim.hasStructure()) {
            return;
        }
        
        final Faction f = FM.getFaction(claim.factionId);
        if (f==null || !f.isMember(p.getName())) {
            return;
        }
        
        //final UserData ud = f.getUserData(p.getName());
        
        final Structure str = claim.getStructureType();
        
        
       
       /* contents.set(0, ClickableItem.of(new ItemBuilder( str.displayMat )
            .name("§e"+str)
            .lore("")
            .lore("")
            .build(), e -> {

            if (e.getClick() == ClickType.LEFT) {
                p.closeInventory();
                p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_FALL, 1, 1);
                return;
            }

            FM.soundDeny(p);

        })); */           

    
        
        
        
        
        
        
        
        
        
        
        
        final int tpDelay = f.getScienceLevel(Science.Материаловедение)==5 ? 5 : 15;
        final int charge = tpDelay - (FM.getTime() - claim.lastUse);
        

        contents.set(0, ClickableItem.of(new ItemBuilder( str.displayMat )
            .name("§e"+str)
            .lore(charge>0 ? "§cЗаряжается : "+charge : "§aЛКМ - выбор точки")
            .lore(f.hasPerm(p.getName(), Perm.Settings) ? "§7ПКМ - §3сменить название" : "§8Нет права менять название!")
            .lore("")
            .lore("")
            .lore("§7Открытие меню ТП:")
            .lore("")
            .lore("§6Для структуры:")
            .lore("§fПКМ на структуру.")
            .lore("")
            .lore("§3Для БАЗЫ:")
            .lore("§fприсесть + ЛКМ на базу")
            .lore("")
            .build(), e-> {
                
                if (e.getClick()==ClickType.LEFT) {
                    
                   /* if (charge>0) {
                        FM.soundDeny(p);
                        p.sendMessage("§cТелепорт заряжается! Осталось: "+charge);
                        reopen(p, contents);
                        return;
                    }*/
                    
                    SmartInventory.builder()
                            .id("TeleportSelect"+p.getName())
                            .provider(new TeleportSelect(claim))
                            .size(4, 9)
                            .title("§2Структуры Телепорта")
                            .build()
                            .open(p);
                    
                    
                } else if (e.getClick()==ClickType.RIGHT) {
                    
                    if (f.hasPerm(p.getName(), Perm.Settings)) {
                        final AnvilGUI ag = new AnvilGUI(Ostrov.instance, p, Land.getClaimName(claim.cLoc).replaceAll("§", "&"), (player, value) -> {
                            if (claim==null) return null;
                            if(value.isEmpty() ) {
                                p.sendMessage("§cНазвание пустое!");
                                FM.soundDeny(p);
                                return null;
                            }
                            if(value.length()>32 ) {
                                p.sendMessage("§cЛимит 32 символа!");
                                FM.soundDeny(p);
                                return null;
                            }
                            if(value.equals(claim.name) ) {
                                p.sendMessage("§cНазвание не изменилось!");
                                FM.soundDeny(p);
                                return null;
                            }
                            claim.name = value.replaceAll("&", "§");
                            DbEngine.saveClaim(claim);
                            p.sendMessage("§aТеперь этот террикон будет отображаться как §f"+claim.name);
                            return null;
                        });
                    } else {
                        FM.soundDeny(p);
                    }
                }
            }
        ));            

         
        
        
        if (f.getLevel()>=7 && f.getScienceLevel(Science.Материаловедение)>=5 && f.getScienceLevel(Science.Разведка)>=5 && f.getScienceLevel(Science.Академия)>=5) {
            
            contents.set(1, ClickableItem.empty(new ItemBuilder(Material.END_STONE )
                .name("§8Отправиться в Край")
                .lore("")
                .lore("Возможность откроется при")
                .lore("статусе")
                .lore(Level.getLevelIcon(7))
                .lore("и "+Sciences.getScienceLogo(5)+" уровне наук:")
                .lore(f.getScienceLevel(Science.Материаловедение)>=5 ? "§aМатериаловедение" : "§cМатериаловедение")
                .lore(f.getScienceLevel(Science.Разведка)>=5 ? "§aРазведка" : "§cРазведка")
                .lore(f.getScienceLevel(Science.Академия)>=5 ? "§aАкадемия" : "§cАкадемия")
                .lore("")
                .lore("")
                .build()
            ));            

        } else {
            
            contents.set(1, ClickableItem.of(new ItemBuilder(Material.END_STONE )
                .name("§bОтправиться в Край")
                .lore("")
                .lore("§7Шифт+ПКМ - тп")
                .lore("")
                .build(), e -> {

                if (e.getClick() == ClickType.SHIFT_RIGHT) {
                    p.closeInventory();
                    DelayTeleport.tp(p, Bukkit.getWorld("world_the_end").getSpawnLocation(), 5, "", true, true, f.getDyeColor());
                    return;
                }

                FM.soundDeny(p);

            }));            

        }

   

        
        contents.set(3, ClickableItem.of(new ItemBuilder(Material.TNT )
            .name("§cСнести")
            .lore("")
            .lore("§7Клав. Q - §сразрушить")
            .lore("")
            .build(), e -> {

            if (e.getClick() == ClickType.DROP) {
                p.closeInventory();
                //Structures.destroyStructure(claim, true, false);
                p.performCommand("f destroy "+str);
                return;
            }

            FM.soundDeny(p);

        }));            
        
        

        
        
        
        contents.set(4, ClickableItem.of( new ItemBuilder(Material.OAK_DOOR).name( "закрыть").build(), e -> 
            p.closeInventory()
        ));
        

        

        


        
        

    }
    
    
    
    
    
    
    
    
    
    
}
