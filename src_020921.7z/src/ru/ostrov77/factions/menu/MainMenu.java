package ru.ostrov77.factions.menu;


import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemStack;
import ru.komiss77.ApiOstrov;
import ru.komiss77.Ostrov;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;
import ru.komiss77.utils.inventory.SmartInventory;
import ru.komiss77.version.AnvilGUI;
import ru.ostrov77.factions.Econ;
import ru.ostrov77.factions.objects.Faction;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.objects.UserData;
import ru.ostrov77.factions.Enums.Perm;
import ru.ostrov77.factions.Land;
import ru.ostrov77.factions.Relations;
import ru.ostrov77.factions.objects.Fplayer;
import ru.ostrov77.factions.turrets.TurretBuilder;
import ru.ostrov77.factions.turrets.TurretMain;



public class MainMenu implements InventoryProvider {

    private final Faction f;
    
    public MainMenu(final Faction f) {
        this.f = f;
    }

    private static final ItemStack up = new ItemBuilder(Material.IRON_BARS).name("§8.").build();
    private static final ItemStack side = new ItemBuilder(Material.CHAIN).name("§8.").build();
    private static final ItemStack down = new ItemBuilder(Material.IRON_BARS).name("§8.").build();;
    
    
    
    
    
    
    @Override
    public void init(final Player p, final InventoryContent contents) {
        p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 5, 5);
        
        contents.fillRow(0, ClickableItem.empty(up));
        contents.fillRow(4, ClickableItem.empty(down));
        contents.fillColumn(0, ClickableItem.empty(side));
        contents.fillColumn(8, ClickableItem.empty(side));

        
        final Fplayer fp = FM.getFplayer(p);
        final UserData ud = f.getUserData(p.getName()); //права текущего 
        final Faction inThisLoc = Land.getFaction(p.getLocation());
        final boolean home = inThisLoc!=null && inThisLoc.factionId==f.factionId;
        //int count=0;
        
        
        /* заготовочка
        contents.set(1, 1, ClickableItem.of( new ItemBuilder(Material.GRAY_BED)
            .name("§2Точка дома")
            .lore("§7Шифт + ПКМ - установить.")
            .lore("§7")
            .lore("§7")
            .lore("§7")
            .build(), e -> {
                if (e.isLeftClick()) {
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1, 5);
                    reopen(player, contents);
                } else {
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASEDRUM, 1, 5);
                }
            }));    
        */
        
        contents.set(0, 4, ClickableItem.of ( FM.getFactionIcon(f,"§7ЛКМ - §eРазвитие клана", "§7ПКМ - §6Архив Королевства", "") , e ->
            {
                switch (e.getClick()) {
                    case LEFT:
                        p.performCommand("f upgrade");//MenuManager.openTop(p, MenuManager.TopType.claims);
                        return;
                    
                    case RIGHT:
                        SmartInventory.builder()
                        .type(InventoryType.HOPPER)
                        .id("SelectStats"+p.getName()) 
                        .provider(new SelectStats())
                        .title("§fЧто Вса интересует?")
                        .build()
                        .open(p);
                        
                        //p.performCommand("f top");//MenuManager.openTop(p, MenuManager.TopType.claims);
                        //p.performCommand("f topwar");//MenuManager.openTopWar(p, MenuManager.TopWarType.kills);
                         //p.performCommand("f disbaned");//MenuManager.openDisbanned(p, 0);
                        return;
                    
                    //case SHIFT_LEFT:
                    //    p.performCommand("f disbaned");//MenuManager.openDisbanned(p, 0);
                    //    return;
                    
                    //case  SHIFT_RIGHT:
                    //    return;
                }

            }
        ));    


        
        
        
        
        
        
        contents.set(1, 1, ClickableItem.of( new ItemBuilder(Material.COMPASS)
            .name("§2Места")
            .lore("§7ЛКМ - точка сбора клана")
            .lore("§7ПКМ - точки сбора союзников")
            .lore("")
            .lore("§7Шифт+ЛКМ - посетить столицу")
            .lore("")
            .build(), e -> {
                switch (e.getClick()) {
                    case LEFT:
                        p.closeInventory();
                        p.performCommand("f home");
                        return;
                    case RIGHT:
                        //места - точки дома союзного клана
                        SmartInventory.builder().id("AllyHome"+p.getName()). provider(new AllyHome(f)). size(3, 9). title("§2Точки сбора союзников").build() .open(p);
                        return;
                    case SHIFT_LEFT:
                        p.performCommand("spawn");//SW.tpCity(player);
                        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1, 5);
                        return;
                }
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASEDRUM, 1, 5);
            }));    
        
        
        
         
   /*     contents.set(1, 2, ClickableItem.of ( new ItemBuilder(Material.EXPERIENCE_BOTTLE)
            .name("§5Путь развития")
            .lore("§7")
            .lore("§7")
            .lore(ud.has(Perm.Uprade)?(home? "§7ЛКМ - §aразвитие клана":"§6*Надо быть на землях клана"):"§8(нет права развития)")
            .lore("§7")
            .build(), e -> {
                switch (e.getClick()) {
                    case LEFT:
                        p.performCommand("f upgrade");
                     return;

                }

            }
        ));    
*/
        
        
        
        
        //ТЕРРИКОНЫ
        
        Land.setMenuIcon(p, fp, f, contents);
        




        //КАЗНАЧЕЙСТВО
        if (f.isAdmin()) {
            
            contents.set(1, 5, ClickableItem.empty(new ItemBuilder(Material.GOLD_INGOT)
                .name("§eКазначейство")
                .lore("§7")
                .lore("§eКлан системный,")
                .lore("§eэкономика отключена.")
                .lore("")
                .build()));
            
            contents.set(1, 7, ClickableItem.empty(new ItemBuilder(Material.LECTERN)
                .name("§eДипломатия")
                .lore("§7")
                .lore("§eКлан системный,")
                .lore("§eдипломатия отключена.")
                .lore("")
                .build()));

            
        } else {
        
            
            Econ.setMenuIcon(p, fp, ud, f, contents);
        
 
        
        
        
            contents.set(1, 7, ClickableItem.of( new ItemBuilder(Material.LECTERN)
                .name("§eДипломатия §5(Уровень §d"+Relations.getLevelLogo(f.getDiplomatyLevel())+"§5)")
                .lore("§7")
                .lore(f.hasWarProtect() ? "§aПокровительство : "+Econ.housrToTime(f.getWarProtect()) : "")
                .lore("")
                .lore(fp.hasPerm(Perm.Diplomacy) ? "§7ЛКМ - отношения с кланами" : "§8нет статуса дипломата")
                .lore(fp.hasPerm(Perm.Diplomacy) ? "§7Шифт+ЛКМ - покровительство" : "§8нет статуса дипломата")
                .lore("§7ПКМ - §eВойны")
                .lore("")
                //.lore(ud.has(Perm.Diplomacy) ? "§7Шифт + ЛКМ - исходящие предложения" : "§8нет права переговоров")
                //.lore(ud.has(Perm.Diplomacy) ? "§7Шифт + ПКМ - входящие предложения" : "§8нет права переговоров")
                .lore(fp.hasPerm(Perm.Diplomacy) ? "§7Клав.Q - покровительство" : "§8нет статуса дипломата")
                .lore("")
                .build(), e -> {
                    switch (e.getClick()) {
                        case LEFT:
                            if (fp.hasPerm(Perm.Diplomacy)) {
                                SmartInventory.builder().id("RelationsMain"+p.getName()). provider(new RelationsMain(f, null)). size(6, 9). title("§bОтношения с кланами").build() .open(p);
                                return;
                            }
                            break;
                        case RIGHT:
                            //if (ud.has(Perm.Diplomacy)) {
                                SmartInventory.builder().id("WarFind"+p.getName()). provider(new WarFind(f)). size(3, 9). title("§4Активные войны").build() .open(p);
                                return;
                            //}
                            //break;
                        case SHIFT_LEFT:
                            if (fp.hasPerm(Perm.Diplomacy)) {
                                SmartInventory.builder().id("WarProtect"+p.getName()). provider(new WarProtect(f)). size(1, 9). title("§2Покровительство").build() .open(p);
                                return;
                            }
                            break;
                    }
                    FM.soundDeny(p);
                }));    

        }
        
        
    
        
        
        
        
   
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
         
        //
        //лкм - строительство - меню стройки - изучено/не изучено, уже есть/нет, инфа по уровню
        //q - снос
        contents.set(2, 2, ClickableItem.of( new ItemBuilder(Material.STONECUTTER)
            .name("§fСтруктуры")
            .lore("§7")
            .lore("§7ЛКМ - обзор структур")
            .lore("§7ПКМ - строительство")
            .lore("")
            .build(), e -> {
                if (!home) {
                    p.sendMessage("§cЭто не террикон вашего клана!");
                    return;
                }
                switch (e.getClick()) {
                    case LEFT:
                        SmartInventory.builder().id("StructureView"+p.getName()). provider(new StructureView(f)). size(6, 9). title("§bСтруктуры - просмотр").build() .open(p);
                        return;
                    case RIGHT:
                        SmartInventory.builder().id("StructureBuild"+p.getName()). provider(new StructureBuild(f)). size(6, 9). title("§eСтруктуры - стройка").build() .open(p);
                        return;
                }
                FM.soundDeny(p);
            }));    
        
        
        
        contents.set(2, 4, ClickableItem.of(new ItemBuilder(Material.OBSERVER)
            .name("§aТурели")
            .lore("§7")
            .lore("§6Субстанция: §b"+(f.getSubstance()==0?"§cпусто":f.getSubstance()))
            .lore("")
            //.lore( ud.has(Perm.UseStars) ? "§7Шифт+ЛКМ - §aпереслать субстанцию" : "§8(нет права пересылки субстанции)")
            .lore(fp.hasPerm(Perm.Turrets) ?    home ? "§7ЛКМ - обзор/настройка":"§eНадо быть на терре клана!"    : "§8нет права на турели")
            .lore(ApiOstrov.isLocalBuilder(p, false) ?  "§eПКМ - возведение (отладка)" : "§7Покупка турелей у торговца.")
            .lore("")
            .lore( f.getSubstance()>0 ? (!f.isAdmin() && fp.hasPerm(Perm.UseSubstance) ? "§7Шифт+ПКМ - §eпередать Субстанцию" : "§8нет права передачи"):"§6*Сгенерируйте субстанцию!" )
            .lore("")
            .build(), e -> {
                switch (e.getClick()) {
                    
                    case LEFT:
                        if (fp.hasPerm(Perm.Turrets) && home) {
                            SmartInventory.builder()
                                .id("TurretMain"+p.getName())
                                .provider(new TurretMain(f))
                                .size(6, 9)
                                .title("§bТурели клана")
                                .build()
                                .open(p);
                            return;
                        }
                        break;
                    case RIGHT:
                        if (ApiOstrov.isLocalBuilder(p, false)) {
                            SmartInventory.builder()
                                .id("TurretBuild"+p.getName())
                                .provider(new TurretBuilder(f))
                                .size(6, 9)
                                .title("§eВозведение турелей")
                                .build()
                                .open(p);
                            return;
                        }
                        break;
                   case SHIFT_LEFT: //переслать субстанцию
                        if (f.isAdmin() || !fp.hasPerm(Perm.UseSubstance)  ||  f.getSubstance()<1) break;
                        final AnvilGUI agui3 = new AnvilGUI(Ostrov.instance, p, "1000", (player, value) -> {
                            if (!ApiOstrov.isInteger(value)) {
                                player.sendMessage("§cДолжно быть число!");
                                FM.soundDeny(player);
                                return null;
                            }
                            final int amount = Integer.valueOf(value);
                            if (amount<1 || amount>100000) {
                                player.sendMessage("§cот 1 до 100000");
                                FM.soundDeny(player);
                                return null;
                            }
                            if (amount>f.getSubstance()) {
                                player.sendMessage("§cВ казне нет столько Субстанции!");
                                FM.soundDeny(player);
                                return null;
                            }
                            SmartInventory.builder().id("SendSubstance"+p.getName()). provider(new SendSubstance(f, amount)). size(4, 9). title("§fПередача Субстанции").build() .open(p);
                            return null;
                        });
                        return; //не будет ретурн - издаст звук ниже
                        
                    
                }
                 FM.soundDeny(p);
            }));    
        
        
        
        
        
            
        
        contents.set(2, 6, ClickableItem.of( new ItemBuilder(Material.PLAYER_HEAD)
            .name("§aОтдел кадров")
            .lore("§7")
            .lore(fp.hasPerm(Perm.ChangePerm) ? "§7ЛКМ - назначения на должность" : "§8нет права назначений")
            .lore(fp.hasPerm(Perm.ChangePerm)  ? "§7ПКМ - полномочия должностей" : "§8нет права настройки")
            .lore("§7")
            .lore(f.factionSize()==0 ? "§fвы одиночка" : "§fВ клане: "+f.factionSize()+" чел.")
            .lore("§7")
            //.lore("§aЛимит участников: §3"+f.getMaxUsers())
            //.lore( ud.has(Perm.Uprade) ?    (Science.can(Science.Участники, f.getLevel())?"§7Клав. Q - лимит §a+1 §7за 20 субст.":"§eРазвейте клан до "+Level.getLevelIcon(Science.Участники.requireLevel)) : "§8Нет права увеличивать")
            .build(), e -> {
                switch (e.getClick()) {
                    case LEFT:
                        if (fp.hasPerm(Perm.ChangePerm) ) {
                            MenuManager.openUserMenu(p, f);
                            return;
                        }
                        break;
                    case RIGHT:
                        if (fp.hasPerm(Perm.ChangePerm) ) {
                            SmartInventory.builder().id("RolePermSettings"+p.getName()). provider(new RolePermSettings(f)). size(3, 9). title("§5Полномочия должностей").build() .open(p);
                            return;
                        }
                        break;
                    /*case DROP:
                        if (!ud.has(Perm.Uprade)) {
                            break;
                        }
                        if (!Science.can(Science.Участники, f.getLevel())) {
                            p.sendMessage("§eДля увеличения лимита клан должны быть уровня §b"+Science.Участники.requireLevel+" §eили выше.");
                            break;
                        }
                        if (f.econ.substance < 20) {
                            p.sendMessage("§cСубстанции недостаточно (мин.20)");
                            break;
                        }
                        ConfirmationGUI.open(p, "§2Увеличить лимит ?", result -> {
                            if (result) {
                                f.econ.substance-=20;
                                f.setMaxUsers(f.getMaxUsers()+1);
                                DbEngine.saveFactionData(f, DbEngine.DbField.data);
                                DbEngine.saveFactionData(f, DbEngine.DbField.econ);
                                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1);
                            } else {
                                FM.soundDeny(p);
                            }
                            reopen(p, contents);
                        });
                        return;*/
                }
                FM.soundDeny(p);
            }));    
        
                
       /* 
        if (!f.isAdmin()) {
            contents.set(2, 6, ClickableItem.of( new ItemBuilder(Material.TOTEM_OF_UNDYING)
                .name("§fРелигия клана")
                .lore("§7")
                .lore(f.getReligy()==Religy.Нет ? "§7Сейчас не выбрана." :  "§7Сейчас : §6"+f.getReligy() )
                .lore("§7")
                .addLore(f.getReligy().desc)
                .lore("§7")
                .lore("§7ЛКМ - выбор религии")
                .lore("")
                .build(), e -> {
                    if (!home) {
                        p.sendMessage("§cНадо быть на терре клана!");
                        return;
                    }
                    switch (e.getClick()) {
                        case LEFT:
                            SmartInventory.builder().id("ReligySelect"+p.getName()). provider(new ReligySelect(f)). size(3, 9). title("§fРелигия").build() .open(p);
                            return;
                        //case RIGHT:
                            //SmartInventory.builder().id("StructureBuild"+p.getName()). provider(new StructureBuild(f)). size(6, 9). title("§eСтруктуры - стройка").build() .open(p);
                            //return;
                    }
                    FM.soundDeny(p);
                }));    
        }
        */
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


            if (fp.hasPerm(Perm.Settings)) {
                contents.set(3, 1, ClickableItem.of(new ItemBuilder(Material.REPEATER)
                    .name("§2Общие настройки")
                    .lore("§7")
                    .lore(fp.hasPerm(Perm.Settings) ? "§7ЛКМ - §eКлановые права доступа" : "§8Нет права настройки доступа!")
                    .lore(fp.hasPerm(Perm.Settings) ? "§7ПКМ - §eКлановые флаги земель": "§8Нет права настройки земель!")
                    .lore(fp.hasPerm(Perm.Settings) ? "§7Шифт+ЛКМ - §2Настройки клана": "§8Нет права настроек клана!")
                    .lore("§7")
                    .lore("§eКлановые права и флаги действуют")
                    .lore("§7на всей терре клана,")
                    .lore("§7но настройки террикона имеют")
                    .lore("§7более высойкий приоритет.")
                    .build(),
                    e -> {
                        switch (e.getClick()) {
                            case LEFT:
                                if (fp.hasPerm(Perm.Settings)) {
                                    SmartInventory.builder().id("FactionAcces"+p.getName()). provider(new FactionAcces(f)). size(4, 9). title("§1Глобальный доступ").build() .open(p);
                                } else break;
                                return;
                            case RIGHT:
                                if (fp.hasPerm(Perm.Settings)) {
                                    SmartInventory.builder().id("GlobalFlags"+p.getName()). provider(new FactionFlags(f)). size(6, 9). title("§1Глобальные флаги").build() .open(p);
                                } else break;
                                return;
                            case SHIFT_LEFT:
                                if (fp.hasPerm(Perm.Settings)) {
                                    SmartInventory.builder().id("SettingsMain"+p.getName()). provider(new SettingsMain(f)). size(6, 9). title("§fНастройки клана").build() .open(p);
                                } else break;
                                return;
                        }
                        FM.soundDeny(p);
                }));
            } else {
                contents.set(3, 1, ClickableItem.empty(new ItemBuilder(Material.REPEATER)
                    .name("§2Настройки клана")
                    .lore("§7")
                    .lore("§cнет права настраивать")
                    .lore("§7")
                    .build()
                ));
            }
        
            
            if (f.isAdmin()) {
                
                contents.set(3, 2, ClickableItem.of( new ItemBuilder(Material.REDSTONE_TORCH)
                    .name("§fЛичное Дело")
                    .lore("§7")
                    .lore("§7Ваше звание: "+ud.getRole().chatPrefix+" "+ud.getRole().displayName)
                    .lore("§7")
                    .lore(ud.getStars()==0? "Накопите личные крац возжиганием!" : "§7У вас §b"+ud.getStars()+" §7личных крац")
                    .lore( "§8Системный клан," )
                    .lore(  "§8экономика отключена.")
                    .lore("§7")
                    .lore("§7ЛКМ - §fуправление")
                    .lore("§7ПКМ - §bкарта в чат")
                    .lore("§b*§7так же можно /f map")
                    .lore("§7")
                    .build(), e -> {
                        if (e.isLeftClick()) {
                            SmartInventory.builder().id("SettingsPersonal"+p.getName()). provider(new SettingsPersonal(f)). size(6, 9). title("§fЛичное Дело").build() .open(p);
                        } else if (e.isRightClick()) {
                            p.closeInventory();
                            p.performCommand("f map");
                        } else {
                            FM.soundDeny(p);
                        }
                }));
                
            } else {
                
                final int tax = f.econ.getTaxByRole(ud.getRole());
                contents.set(3, 2, ClickableItem.of( new ItemBuilder(Material.REDSTONE_TORCH)
                    .name("§fЛичное Дело")
                    .lore("§7")
                    .lore("§7Ваше звание: "+ud.getRole().chatPrefix+" "+ud.getRole().displayName)
                    .lore("§7")
                    .lore(ud.getStars()==0? "Накопите личные крац возжиганием!" : "§7У вас §b"+ud.getStars()+" §7личных крац" + (fp.hasPerm(Perm.UseStars)?".":", налог: §6"+tax+"крац §7в "+Econ.housrToTime(Econ.PLAYER_TAX_INTERVAL)))
                    .lore( fp.hasPerm(Perm.UseStars) ? "§8Лидер и казначей освобождены"  :  (f.econ.stars>=tax ? "§aКрац достаточно для уплаты налога." : "§cНедостаточно крац для уплаты налога!") )
                    .lore( fp.hasPerm(Perm.UseStars) ? "§8от кланового налога."  :  (ud.getStars()>=tax ? "§7До кланового налога: §6"+Econ.housrToTime(f.econ.memberTax) : "§cДо изгнания из клана: §4"+Econ.housrToTime(f.econ.memberTax)) )
                    .lore("§7")
                    .lore("§7ЛКМ - §fуправление")
                    .lore("§7ПКМ - §bкарта в чат")
                    .lore("§b*§7так же можно /f map")
                    .lore("§7")
                    .build(), e -> {
                        if (e.isLeftClick()) {
                            SmartInventory.builder().id("SettingsPersonal"+p.getName()). provider(new SettingsPersonal(f)). size(6, 9). title("§fЛичное Дело").build() .open(p);
                        } else if (e.isRightClick()) {
                            p.closeInventory();
                            p.performCommand("f map");
                        } else {
                            FM.soundDeny(p);
                        }
                }));

            }

                
        
        
        
        final int canInvite =  f.getMaxUsers() - f.factionSize();
        
        if (fp.hasPerm(Perm.Invite) && canInvite>0) {   
            int count = 0;
            for (final Player p1 : Bukkit.getOnlinePlayers()) {
                if ( FM.getFplayer(p1.getName())!=null && FM.getPlayerFaction(p1)==null ) count++;
            }
            final int c2=count;


            contents.set(3, 4, ClickableItem.of( new ItemBuilder(Material.FLOWER_BANNER_PATTERN)
                .name("§eПриглашения")
                .lore("§7")
                .lore("§7ЛКМ - меню приглашений")
                .lore("§7ПКМ - обновить")
                .lore("§7")
                .lore("§7Пригласить свободных игроков в клан")
                .lore("§7")
                //.lore( canInvite>0 ? "§6Вы можете пригласить еще §e"+canInvite+" §6чел." : (ApiOstrov.hasGroup(player.getName(), "vip") ? "§cлимит приглашений" : "§счтобы пригласить еще, станьте vip") )
                .lore( "§6Вы можете пригласить еще §e"+canInvite+" §6чел.")//  )
                .lore( count >0 ? "§eдоступны для приглашеня: §b"+count : "§cфрименов не найдено..")
                .lore("§7")
                .build(), e -> {
                    if (e.isLeftClick()) {
                        if (c2>0) {
                            MenuManager.openInviteMenu(p, f);
                        } else {
                            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASEDRUM, 1, 5);
                        }
                    } else if (e.isRightClick()) {
                        p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 1, 5);
                        reopen(p, contents);
                    }
                }));    
        } else {
             contents.set(3, 4, ClickableItem.empty(new ItemBuilder(Material.FLOWER_BANNER_PATTERN)
                .name("§eПриглашения")
                .lore("§7")
                .lore( canInvite>0 ? "§6Нет прав приглашать" : "§cлимит размера клана")
                .lore("§7")
                .build())
             );
        }
        
        
        
        contents.set(3, 6, ClickableItem.of( new ItemBuilder(Material.COBWEB)
            .name("§fМеню серверов")
            .lore("§7")
            .lore("§7")
            .lore("§7ЛКМ - открыть")
            .lore("§7")
            .build(), e -> {
                if (e.isLeftClick()) {
                    //player.closeInventory();
                    p.performCommand("serv");
                }
            }));    
        
        
        
        
        contents.set(3, 7, ClickableItem.of( new ItemBuilder(Material.WRITABLE_BOOK)
            .name("§7Журнал событий")
            .lore("§7")
            .lore(fp.hasPerm(Perm.ViewLogs) ? "§7ЛКМ - просмотр журнала" : "§cнет права просмотра")
            .lore("§7")
            .build(), e -> {
                if (e.isLeftClick() && fp.hasPerm(Perm.ViewLogs)) {
                    p.closeInventory();
                    p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 1, 5);
                    MenuManager.openJournal(p, f, 0);
                } else {
                    FM.soundDeny(p);
                }
            }));    
    

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        contents.set( 4, 4, ClickableItem.of( new ItemBuilder(Material.OAK_DOOR).name("§4закрыть").build(), e ->
            p.closeInventory()
        ));       

        
        

    }
    
    
        
}
