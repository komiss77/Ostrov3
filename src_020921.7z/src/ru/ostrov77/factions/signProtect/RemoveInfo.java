package ru.ostrov77.factions.signProtect;


public final class RemoveInfo {

    public final int cLoc;
    public final int sLoc;
    
    public RemoveInfo(final int cLoc, final int sLoc) {
        this.cLoc = cLoc;
        this.sLoc = sLoc;
    }
    

    
}
