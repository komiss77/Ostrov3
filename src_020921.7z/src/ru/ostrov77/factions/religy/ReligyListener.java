
package ru.ostrov77.factions.religy;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.objects.Fplayer;





public class ReligyListener implements Listener {
   
    
    
    
    
    
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onEat(final PlayerItemConsumeEvent e) {
//System.out.println("+onEat "+e.getItem().getType());
        final Player p = e.getPlayer();
        final Fplayer fp = FM.getFplayer(p);
        if (fp!=null) {
        fp.updateActivity();
            if (fp.getFaction()!=null && fp.getFaction().getReligy()!=Religy.Нет) {
                final ItemStack is = e.getItem();
                //Relygyons.onEat(p, fp.getFaction(), e.getItem());
                    switch (fp.getFaction().getReligy()) {
            
                    case Первобытность: //Сырая еда исцеляет
                        if (String.valueOf(is.getType()).contains("COOKED")) return;
                        switch (is.getType()) {
                            case MUSHROOM_STEW:
                            case BREAD:
                            case CAKE:
                            case COOKIE:
                            case ROTTEN_FLESH:
                            case SPIDER_EYE:
                            case BAKED_POTATO:
                            case POISONOUS_POTATO:
                            case PUMPKIN_PIE:
                            case RABBIT_STEW:
                            case BEETROOT_SOUP:
                                return;
                        }
                        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 5));
                        //p.setHealth(p.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue());
                        break;

                    case Ислам:

                        if (is.getType()==Material.PORKCHOP || is.getType()==Material.COOKED_PORKCHOP) { //Смерть от свинины
                            p.setHealth(0);
                            p.sendMessage("§eИслам и свинина несовместимы!");
                        }   
                        break;

                    case Буддизм:
                        if (String.valueOf(is.getType()).contains("POTION")) {//Смерть от любых зелий, но только при употреблении ПКМ!!
                            p.setHealth(0);
                            p.sendMessage("§eБуддизм не одобряет зелья!");
                        }   
                        break;
                } 
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
