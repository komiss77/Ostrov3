
package ru.ostrov77.factions.religy;

import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.komiss77.ApiOstrov;
import ru.ostrov77.factions.Wars;
import ru.ostrov77.factions.religy.Religy;
import ru.ostrov77.factions.objects.Faction;



public class Relygyons {

    public static int CHANGE_INTERVAL = 7 * 24 * 60 * 60 ;
    
    
    
    
    
    //вызывается только при смене или выборе религии клана
    public static void onChange(final Faction f, final Religy religy) {
        if (religy==null || religy==Religy.Нет) {
            f.broadcastMsg("§fКлан больше не испытывает религиозных чувств.");
        } else {
            f.broadcastMsg("§fРелигиозный выбор клана можно определить, как §b"+religy);
        }
        for (final Player p : f.getFactionOnlinePlayers()) {
            applyReligy(p, religy);
            p.playSound(p.getLocation(), Sound.AMBIENT_BASALT_DELTAS_MOOD, 16, 1);
        }
    }
    
    
    
    
    //вызывается: 
    //- при смене религии клана
    //- при выходе из клана
    //- при роспуске клана
    //-при входе на сервер
    //- при респавне
    
    public static void applyReligy(final Player p, final Religy newReligy) {
//System.out.println("---applyReligy "+p.getName()+" : "+religy);
        //final Fplayer fp = FM.getFplayer(p);
       // if (newReligy==null || newReligy==Religy.Нет || fp==null || fp.getFaction()==null) { //сброс религии
            //сбросить надо всегда! или при смене останутся эффекты от старой религии
            setHealth (p, 20);
            p.setGlowing(false);
            for(PotionEffect e : p.getActivePotionEffects()){
                //if (e.getType()==PotionEffectType.SLOW_DIGGING) {
                    p.removePotionEffect(e.getType());
                //}
            }
            clearFortune(p);
     //   } else {
            
            switch (newReligy) {
                case Первобытность:
                    boolean unequip = false;
                    ItemStack[] armor = p.getInventory().getArmorContents();
                    for (int i=0; i<armor.length; i++) {
                        if (armor[i]!=null && armor[i].getType()!=Material.AIR && !armor[i].getType().toString().contains("LEATHER_")) {
                            p.getWorld().dropItemNaturally(p.getLocation(), armor[i]);
                            armor[i] = null;
                            unequip = true;
                        }
                    }
                    if (unequip) {
                        p.getInventory().setArmorContents(armor);
                        p.updateInventory();
                        p.sendMessage("§eРелигия клана - только кожа!");
                    }
                    break;
                case Мифология:
                    changeFortune(p);
                    break;
                case Ислам:
                    setHealth(p, 24);
                    p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, Integer.MAX_VALUE, 1));
                    break;
                case Буддизм:
                    setHealth(p, 30);
                    if (p.getFoodLevel()>10) p.setFoodLevel(10);
                    break;
                case Христианство:
                    p.setGlowing(true);
                    break;
                case Атеизм:
                    setHealth(p, 26);
                    break;
                default:
                    setHealth(p, 20);
                    break;
            }
            
       // }
    }
    
    
    
    
    private static void setHealth(final Player p, final int health) {
        p.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(health);
        p.setHealth(p.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue());
    }
    
    
    
    

    
    
    //вызывается из PlayerDeathEvent.
    //при условии killer != null && !killer.getName().equals(p.getName())
    //учитывать, что killerFaction и targetFaction может быть null!!! (т.е. дикари)
    public static void onKill(final Player killer, final Faction killerFaction, final Player target, final Faction targetFaction) {
        
        if (killerFaction!=null && killerFaction.getReligy()==Religy.Атеизм && targetFaction!=null && targetFaction.getReligy()!=Religy.Нет) { //5 секунд тьмы и слабости за убийство верующих
            
            killer.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 15*20, 5));
            killer.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 15*20, 5));
            
        } else if (killerFaction!=null && killerFaction.getReligy()==Religy.Мифология) { //Убийство врага полностью исцеляет
            
            if (targetFaction==null || Wars.canInvade(killerFaction.factionId, targetFaction.factionId) || Wars.canInvade(targetFaction.factionId, killerFaction.factionId)) {
                killer.setHealth(killer.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue());
            }
            
        } else if (targetFaction!=null && targetFaction.getReligy()==Religy.Христианство) { //Убийство врага полностью исцеляет
            
            killer.setHealth(0);
            killer.sendMessage("§eБожество клана "+targetFaction.getName()+" §eпокарало вас!");
            
        }
        
    }

    
    
    //вызывается при выборе мифологии и каждый час онлайна игрока (если религия клана мифология)
    public static void changeFortune(final Player p) {
        clearFortune(p);
        final int luck = 5 - ApiOstrov.randInt(0, 10);
       // if (p.getAttribute(Attribute.GENERIC_LUCK)!=null && p.getAttribute(Attribute.GENERIC_LUCK).getModifiers()!=null && !p.getAttribute(Attribute.GENERIC_LUCK).getModifiers().isEmpty()) {
       //     p.getAttribute(Attribute.GENERIC_LUCK).getModifiers().removeIf( at-> at.getName().equals("Колесо фортуны") );
            //for (AttributeModifier am : p.getAttribute(Attribute.GENERIC_LUCK).getModifiers()) {
            //    if (am.getName().equals("Колесо фортуны")) {
            //        p.getAttribute(Attribute.GENERIC_LUCK).getModifiers().remove(am);
            //    }
            //}
       // }
        p.getAttribute(Attribute.GENERIC_LUCK).addModifier(new AttributeModifier(UUID.randomUUID(), "Колесо фортуны", luck, AttributeModifier.Operation.ADD_NUMBER));
        if (luck==0) {
            p.sendMessage("§fКолесо Фортуны сделало оборот, ближайший час удача будет обычная.");
        } else {
            p.sendMessage("§fКолесо Фортуны сделало оборот, ближайший час удача "+(luck>0?"§2+"+luck:"§4"+luck));
        }
    }

    private static void clearFortune(final Player p) {
        if (p.getAttribute(Attribute.GENERIC_LUCK)!=null && !p.getAttribute(Attribute.GENERIC_LUCK).getModifiers().isEmpty()) {
            for (AttributeModifier am : p.getAttribute(Attribute.GENERIC_LUCK).getModifiers()) {
                if (am.getName().equals("Колесо фортуны")) {
                     p.getAttribute(Attribute.GENERIC_LUCK).removeModifier(am);
                }
            }
        }
    }

    
}
