package ru.ostrov77.factions;

import ru.ostrov77.factions.turrets.TM;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Random;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.hover.content.Text;
import ru.ostrov77.factions.signProtect.LockListener;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import ru.komiss77.ApiOstrov;
import ru.komiss77.Ostrov;
import ru.komiss77.modules.menuItem.MenuItemBuilder;
import ru.komiss77.utils.ItemBuilder;
import ru.ostrov77.factions.jobs.JobListener;
import ru.ostrov77.factions.listener.ChatListen;
import ru.ostrov77.factions.listener.BlockListen;
import ru.ostrov77.factions.listener.InteractListen;
import ru.ostrov77.factions.listener.MainListen;
import ru.ostrov77.factions.listener.PlayerListen;
import ru.ostrov77.factions.religy.ReligyListener;
import ru.ostrov77.factions.setup.SetupManager;
import ru.ostrov77.factions.trade.TradeListener;









public class Main extends JavaPlugin {
    public static Main plugin;
    public static SetupManager setupManager;
    public static FilesManager filesManager;    
    public static int createPrice = 10;
    public static Random r;
    public static String lobbyWorldName;
    public static boolean canLogin = false;
    public static ItemStack book;
    
    public static HashMap <Integer, String> worldNames;
    public static AchievementsManager achievementsManager;
    
    
    @Override
    public void onEnable() {
        plugin = this;
        worldNames = new HashMap<>();
       
        for (final World w : Bukkit.getWorlds()) {
            checkWorldNames(w);
        }
        r = new Random();
        Load_book();
        filesManager = new FilesManager(this);
        setupManager = new SetupManager(plugin);
        achievementsManager = new AchievementsManager(this);
        
        final FM fm = new FM(plugin);
        Land.init(); //там и загрузкоа!
        Relations.init(); //перед загрузкой! там инится хранилище!
        Wars.init(); //перед загрузкой! там инится хранилище!
        Sciences.init();
        
        
        Bukkit.getPluginManager().registerEvents(new Econ(this), this);
        Bukkit.getPluginManager().registerEvents(new Level(this), this);
        
        //Bukkit.getPluginManager().registerEvents(new Structures(this), this);
        TM turrets = new TM(plugin); // +там Bukkit.getPluginManager().registerEvents(new TurretsListener(), this);
        
        Bukkit.getPluginManager().registerEvents(new MainListen(), this);
        Bukkit.getPluginManager().registerEvents(new TradeListener(), this);
        Bukkit.getPluginManager().registerEvents(new BlockListen(), this);
        Bukkit.getPluginManager().registerEvents(new InteractListen(), this);
        Bukkit.getPluginManager().registerEvents(new PlayerListen(), this);
        Bukkit.getPluginManager().registerEvents(new JobListener(), this);
        Bukkit.getPluginManager().registerEvents(new ReligyListener(), this);
        
        this.getServer().getPluginManager().registerEvents(new LockListener(), this);//LockettePro.onEnable();
        
        sync(()-> { 
            if (Ostrov.deluxechatPlugin!=null) Bukkit.getPluginManager().registerEvents(new ChatListen(this), this);
        }, 40);
        
        //создаём предмет - менюшку
        new MenuItemBuilder ("factions",
                new ItemBuilder(Material.MOJANG_BANNER_PATTERN)
                    .name("§aЛенная грамота")
                    .lore("§aПКМ §7- меню кланов")
                    .lore("§aШифт+ПКМ §7- руководство")
                    .lore("§aЛКМ §7- серверное меню")
                    .build()
                )
            .rightClickCmd("f")
            .rightShiftClickCmd("f openbook")
            .leftClickCmd("serv")
            .add();
        
        
        //final SpecItem swMenu = new SpecItem("factions", new ItemBuilder(Material.MOJANG_BANNER_PATTERN)
        //    .name("§aЛенная грамота")
        //    .lore("§aПКМ §7- меню кланов")
        //    .lore("§aШифт+ПКМ §7- руководство")
         //   .lore("§aЛКМ §7- серверное меню")
         //   .build()
         //   );
        //swMenu.slot = 8;
        //swMenu.anycase = false;
        //swMenu.can_drop = true;
        //swMenu.can_move = true;
        //swMenu.can_pickup = true;
        //swMenu.duplicate = false;
        //swMenu.give_on_join = true;
       // swMenu.give_on_respavn = true;
        //swMenu.give_on_world_change = true;
        //swMenu.on_right_click = p -> p.performCommand("f");
        //swMenu.on_right_sneak_click = p -> p.performCommand("f openbook");
        //swMenu.on_left_click = p -> p.performCommand("menu");
        //Ostrov.lobby_items.addItem(swMenu);
        
        plugin.getCommand("f").setExecutor(new CommandFaction(plugin));
        
        canLogin = true;
    }
    
    
    @Override
    public void onDisable() {
        //for (Island is : IM.islands.values()) { - не надо, сохраняются по мере нужды
        //    is.save(false);
        //}
        
        log_ok("выгружен");
        
    }

    
    
    
    
    

    
   private static void Load_book() {
       
        book = new ItemBuilder(Material.WRITTEN_BOOK)
                .name("Дневник дикаря")
                .build();
        BookMeta bookMeta = (BookMeta) book.getItemMeta();

   // BaseComponent[] page = new ComponentBuilder("Click me")
    //    .event(new ClickEvent(ClickEvent.Action.OPEN_URL, "http://spigotmc.org"))
    ////    .event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("Go to the spigot website!").create()))
    //    .create();
     //   bookMeta.spigot().addPage(page);
        
        BaseComponent[] p = new ComponentBuilder("§1Впервые попав на ")
        .append(new ComponentBuilder("§bсрединные земли").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Miðgarðr — «срединная земля»"))).create())
        .append(new ComponentBuilder(" §1меня удивило, насколько здесь развита цивилизация. Сердце этой империи - старинный клан, достигший небывалых высот в техническом развитии. Он занимает оргомную территорию, кажется, не меньше 800 ").create())
        .append(new ComponentBuilder("§bтерриконов").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Террикон - базовая единица площади Мидгарда, 16*16 блоков."))).create())
        .append(new ComponentBuilder("§1.").create())
        .create();
        bookMeta.spigot().addPage(p);

        
        p = new ComponentBuilder("§1И хотя он давно не участвует в дрязгах остальных жителей мида, все защитные механизмы исправны, и никто не осмелится бросить вызов ему или любому другому клану, который смог получить ")
        .append(new ComponentBuilder("§bпокровительсво").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Получают все новые кланы на неделю. Даёт иммунитет к объявлению войны.Можно отказаться, или в дальнейшем продлить."))).create())
        .append(new ComponentBuilder(" §1этого королевства.").create())
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1Итак, я на спавне. Всё, что у меня есть - ")
        .append(new ComponentBuilder("§bленная грамота").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Предмет - меню. Если держать в руке и ПКМ - меню кланов, ЛКМ - серверное меню, Шифт+ПКМ - читать дневник."))).create())
        .append(new ComponentBuilder(" §1. Все вокруг суетятся, похваляются своими родословными и кричат ").create())
        .append(new ComponentBuilder("§b«дикарь, дикарь!»").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Безклановый игрок"))).create())
        .append(new ComponentBuilder(" §1 Сначала это кажется унизительным. Но потом я понимаю, что переполох вызван не моим странным видом.").create())
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1Изучив ленную грамоту замечаю, что она переполнена предложениями ")
        .append(new ComponentBuilder("§bвступить в клан") .event( new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Морковка на удочке в меню"))).create())
//HoverEvent he=new HoverEvent(HoverEvent.Action.SHOW_ITEM,new BaseComponent[]{new TextComponent(CraftItemStack.asNMSCopy(ItemStack).save(new NBTTagCompound()).toString())});
        //.append(new ComponentBuilder("§bвступить в клан") .event( new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text( CraftItemStack.asNMSCopy(new ItemStack(Material.CARROT_ON_A_STICK)).save(new NBTTagCompound()).toString()) )).create())
        .append(new ComponentBuilder("§1. Это сейчас я понимаю, что свежая кровь нужна всем как воздух - ведь чем больше жителей в клане, тем больше он может ").create())
        .append(new ComponentBuilder("§bприсоединить терриконов").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Нужно поддерживать оптимальный баланс земель: на каждого игрока 2-4 террикона. При перенаселении отключается клан-приват, при недонаселении нет дохода в казну."))).create())
        .append(new ComponentBuilder("§1.").create())
        .create();
        
        bookMeta.spigot().addPage(p);
        p = new ComponentBuilder("§1И тогда все действительно хотели принять меня в свою семью, а не глумились. Я мог спокойно принять приглашение самого достойного клана, и жить долго и счастливо. Но тогда я «закусил удила» и пошел изучать местность.")
        .create();
        bookMeta.spigot().addPage(p);
        
         p = new ComponentBuilder("§1Я познакомился на спавне со многими его обитателями, все они говорили о том, что ")
        .append(new ComponentBuilder("§bДикарям").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Чтобы перестать быть дикарём, нужно войти в клан или создать свой."))).create())
        .append(new ComponentBuilder(" §1ничем не могут помочь. Некоторые запросили за свою работу оплату, несколько ").create())
        .append(new ComponentBuilder("§bКРАЦ").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Основная валюта Мидгарда - Звезда Ада. Может применяться в натуральном виде, или безналичном."))).create())
        .append(new ComponentBuilder("§1. А у меня в кармане мышь повесилась. Нашелся некий местный барон, звали его Майкл.").create())
        .create();
        bookMeta.spigot().addPage(p);

        p = new ComponentBuilder("§1 Он предложил мне работу, что бы получить эти самые крац. Дело казалось нехитрым: в основном, заниматься переработкой или добычей. Конечно, был вариант добыть крац самому в Аду, но чёрт побери, с голой жёпой охотиться на Визеров?! ")
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1Я не в игре, и жизнь у меня только одна. Не найдя никаких подводных камней, согласился подработать ")
        .append(new ComponentBuilder("§bсанитаром").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Один из нескольких видов работ. Выбрать можно только один! При смене прогресс теряется!"))).create())
        .append(new ComponentBuilder("§1. \"Для начала пойдет\", - подумал я. Далее мое внимание привлек Путешевственник.").create())
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1Мы с ним разговорились, и поведал он мне о многих местах, где еще не бывала нога человека. Предложил показать к ним путь. Заманчиво, ноо... И здесь мало где бывала моя нога. Я отблагодарил его и пошел дальше.")
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1А дальше вышел на просторы. И тут ждал меня неприятный сюрприз - моя книга рецептов куда-то пропала, и в голове пусто.. Сделать почти ничего невозможно. Только каменный топор. Бродил несколько дней вокруг да около.")
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1Сделать ничего толком не могу, а жрать охота. Ну, в общем, решился создать свой клан. И снова незадача - сколько хватало глаз, всё вокруг застроено и занято. Отовсюду гонят. А в одном месте ")
        .append(new ComponentBuilder("§bкакое-то строение молниями ").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("скорее всего, это была турель Тесла какого-то развитого клана, настроенная на атаку на дикарей."))).create())
        .append(new ComponentBuilder(" §1меня хорошенько так ").create())
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1отжарило, волосы дыбом, еле ноги унёс. И тут вспомнился Путешественник. Да и сумма небольшая к тому времени накопилась, ")
        .append(new ComponentBuilder("§b3 требования для создания своего клана").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("В меню дикаря требования на иконке создания - быть на диких землях, 10 терриконов до другого клана, 10 крац пошлина"))).create())
        .append(new ComponentBuilder(" §1готов был удовлетворить. Нехватало только пару крац.").create())
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1И вот, с помощью доброго НПС, меня перенесло в какое-то далёкое место. Обустроил себе землянку, накопил заветные 10 крац. Местность в целом мне понравилась - красивый ландшафт, зверья да ресурсов сколько хочешь.")
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1Решил обосноваться здесь. И вот, заветный штамп в ")
        .append(new ComponentBuilder("§bленной грамоте").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("клик на иконку создания клана в меню дикаря"))).create())
        .append(new ComponentBuilder(" §1 - и я ").create())
        .append(new ComponentBuilder("§bЛИДЕР").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("главное звание в клане. Кроме лидера, есть еще офицеры, техники, рядовые и рекруты."))).create())
        .append(new ComponentBuilder(" §1собственного клана, в котором только я, чикибамбони и пара куриц!!! Сразу навалилось куча обязанностей, и какое-то время ушло, чтобы освоить управление.").create())
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1Но хоть в одном меня точно не обманули - мой ")
        .append(new ComponentBuilder("§bОчень Крутой Клан").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Начальные настройки. Конечно, вы можете сделать всё как надо: название, девиз,цвет и т.д."))).create())
        .append(new ComponentBuilder(" §1получил заветное покровительство того самого замка, в котором я был, и они будут меня охранять неделю. Видя, какие замки и механизмы есть у других кланов,").create())
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1это было хорошей новостью. Иначе, мне могли объявить войну и просто раскатать в грязь. Конечно, изначально клан был немного лоховcким, выживали с трудом, но от покровительсва не отказывался, продлевал каждую неделю.")
        .create();
        bookMeta.spigot().addPage(p);
        
         p = new ComponentBuilder("§1Явно требовалось какое-то развитие - прокачка, что-ли... Я решил вернуться на территорию замка и поинтересоваться на этот счёт. Познакомился с Саймоном, он предложил мне помощь в развитии статуса клана, не за просто так, конечно, ")
        .create();
        bookMeta.spigot().addPage(p);

        p = new ComponentBuilder("§1а в обмен на интересующие его ресурсы. Запросы такие не хилые, но делать нечего, пошел добывать. Одному тяжело как-то. Как тут слышу в городе шум. Прислушался. А там кричат \"Дикарь! Дикарь!\"")
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1И в голове мысль - а почему бы и нет? Помошник нужен. Срочно отправляю сообщение. А, чёрт, забыл.. ")
        .append(new ComponentBuilder("§bЗона 300").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Один из режимов работы чата, сообщения видны в радиусе 300 блоков."))).create())
        .append(new ComponentBuilder(" §1ломанулся бегом в город. Да, точно дикарь. Свеженький. Кланяюсь и говорю: айда в мой клан, не обижу, в любой момент ").create())
        .append(new ComponentBuilder("§bуйти сможешь").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text("Выйти из клана можно через меню, раздел личное дело"))).create())
                .append(new ComponentBuilder("§1, выходное пособие").create())
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1обеспечу. Человек согласился, и теперь нас двое - лидер и Рекрут. Вдвоём работа заспорилась. Саймон рассказал мне, что тут очень много кто, предлагает свои услуги по продвижению клана в топ за определенные ресурсы,")
        .create();
        bookMeta.spigot().addPage(p);
        
        p = new ComponentBuilder("§1для этого их надо искать в старинном городе. Я начал осматриваться и знакомиться со всеми и паралельно развивая свой клан. Так и начнётся моя великая и очень долгая война за звание самой могущественной империи.")
        .create();
        bookMeta.spigot().addPage(p);

        p = new ComponentBuilder("§1Чувствую, впереди ожидают меня реки.. нет, моря пролитой крови, и великих побед. Но это стоит того, что бы стать самым главным и знаменитым кланом во всем среднем мире. \n\n§4§lВперед к победе!!!")
        .create();
        bookMeta.spigot().addPage(p);



        
        /*
        p = new ComponentBuilder("§1")
        .append(new ComponentBuilder("§b").event(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text(""))).create())
        .append(new ComponentBuilder(" §1").create())
        .create();
        bookMeta.spigot().addPage(p);
        

        */       
        
        bookMeta.setTitle("Miðgarðr");
        bookMeta.setAuthor("комисс77");

        book.setItemMeta(bookMeta);
       
   } 
    
    
    
    public static void tpLobby(final Player p) {
        if (p.getVehicle()!=null) {
            p.getVehicle().eject();
        }
        if (ApiOstrov.getWarpManager().exist("spawn")) {
            p.performCommand("warp spawn");
        } else {
            ApiOstrov.teleportSave(p, Bukkit.getWorlds().get(0).getSpawnLocation(), true);
        }
        //player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation(), PlayerTeleportEvent.TeleportCause.COMMAND);
    }
    
    
    
    
    
    public static void sync(final Runnable runnable, final int delayTicks) { //sync ( ()->{} ,1 );
        if (runnable==null) return;
        new BukkitRunnable() {
            @Override
            public void run() {
                runnable.run();
            }
        }.runTaskLater(plugin, delayTicks);
    }
    
    public static void async(final Runnable runnable, final int delayTicks) { //sync ( ()->{} ,1 );
        if (runnable==null) return;
        new BukkitRunnable() {
            @Override
            public void run() {
                runnable.run();
            }
        }.runTaskLaterAsynchronously(plugin, delayTicks);
    }
    
    
    
    
    
    
    
    
    
    
    public static void log_ok(String s) {   Bukkit.getConsoleSender().sendMessage("§6[§eКланы§6] "+"§2"+ s); }
    public static void log_warn(String s) {   Bukkit.getConsoleSender().sendMessage("§6[§eКланы§6] "+"§6"+ s); }
    public static void log_err(String s) {
        Bukkit.getConsoleSender().sendMessage("§6[§eКланы§6] "+"§c"+ s);
        try {
            final Connection connection = ApiOstrov.getLocalConnection();
            final PreparedStatement pst1 = connection.prepareStatement("INSERT INTO `errors` (`msg`) VALUES (?);");
//System.out.println("1");
            pst1.setString(1, s);
            pst1.execute();
            pst1.close();

        } catch (SQLException ex) {
            //SW.log_err("не удалось сохранить статистику острова "+owner+" : "+ex.getMessage());  !!Нельзя, зациклит!
            ex.printStackTrace();
        }    
    }

    public static void checkWorldNames(final World w) {
        final File file = new File(plugin.getDataFolder() , "worldNames.yml");
        final YamlConfiguration worldNamesConfig = YamlConfiguration.loadConfiguration(file);
        
        final String nameLenght = String.valueOf(w.getName().length());
        
        if (worldNamesConfig.getString(nameLenght)==null || worldNamesConfig.getString(nameLenght).isEmpty()) { 
            worldNamesConfig.set(nameLenght, w.getName());
            worldNames.put(w.getName().length(), w.getName());
            try {
                worldNamesConfig.save(file);  //если такая длинна не использовалась ранее, первый раз просто сохраняет
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            return;
        }
        
        if (worldNamesConfig.getString(nameLenght).equals(w.getName())) { //если длина совпадает со старым названием
            worldNames.put(w.getName().length(), w.getName());
            return; //всё ок
        } 
        //сюда доходит, если длинна не совпадает со старым названием
        if (worldNames.containsKey(w.getName().length()) ) { //если пытаемся загрузить еще один мир с одинаковой длинной
            Bukkit.getConsoleSender().sendMessage("§c=========================================");
            Bukkit.getConsoleSender().sendMessage("§cАлгоритм быстрой обработки локаций");
            Bukkit.getConsoleSender().sendMessage("§cтребует уникальной длинны названия мира!");
            Bukkit.getConsoleSender().sendMessage("§cДлинна названия мира "+w.getName()+" уже занята.");
            Bukkit.getConsoleSender().sendMessage("§cРабота невозможна.");
            Bukkit.getConsoleSender().sendMessage("§c=========================================");
        } else {
            Bukkit.getConsoleSender().sendMessage("§c=========================================");
            Bukkit.getConsoleSender().sendMessage("§cАлгоритм быстрой обработки локаций");
            Bukkit.getConsoleSender().sendMessage("§cтребует уникальной длинны названия мира!");
            Bukkit.getConsoleSender().sendMessage("§cК длинне "+nameLenght+" раннее был привязан мир "+w.getName()+",");
            Bukkit.getConsoleSender().sendMessage("§cСохранённые в БД данные могут работать некорректно!.");
            Bukkit.getConsoleSender().sendMessage("§c=========================================");
        }
        Bukkit.shutdown();

    }
   
    
    
    
    
    
    
    
    
    
    
}
