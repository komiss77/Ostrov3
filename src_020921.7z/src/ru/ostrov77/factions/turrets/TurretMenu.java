package ru.ostrov77.factions.turrets;


import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;
import ru.komiss77.utils.inventory.SmartInventory;
import ru.ostrov77.factions.DbEngine;
import ru.ostrov77.factions.DbEngine.DbField;
import ru.ostrov77.factions.Enums.Science;
import ru.ostrov77.factions.FM;
import ru.ostrov77.factions.objects.Faction;




public class TurretMenu implements InventoryProvider {
    
    
    private final Turret turret;
    //private static final ItemStack fill = new ItemBuilder(Material.LIME_STAINED_GLASS_PANE).name("§8.").build();;

    
    public TurretMenu(final Turret turret) {
        this.turret = turret;
    }
    
    
    
    @Override
    public void init(final Player p, final InventoryContent contents) {
        //p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 5, 5);
        //contents.fillRect(0,0, 2,3, ClickableItem.empty(fill1));
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_CONDUIT_ATTACK_TARGET, 15, 2);
        
        if (turret==null || turret.getClaim()==null) {
            return;
        }
        
        final Faction f = turret.getFaction();
        if (f==null || !f.isMember(p.getName())) {
            return;
        }
        //final boolean inTclaim = Land.getcLoc(p.getLocation()) == turret.cLoc;

        final Specific current = TM.getSpecific(turret.type, turret.level);
       
        contents.set(3, ClickableItem.empty( new ItemBuilder(current.logo)
                .name("§7Уровень: §6"+TM.getLevelLogo(turret.level))
                .lore("")
                .lore("§7• §2Защита: §6"+turret.getShieldInfo()+" §7макс."+turret.getMaxShield())
                .lore("§7• §2Дальность: §6"+turret.radius)
                .lore("§7• §2Сила: §6"+turret.power)
                .lore("§7• §2Перезаряд: §6"+turret.recharge)
                .lore("§7• §2Расход субстанции: §6"+turret.substRate)
                .lore("")
                .lore( turret.isDamaged() ? "§eТребуется ремонт!" : (turret.disabled ? "§cВыключена" : "§aТурель исправна."))
                .lore( turret.isDamaged() ? "§eВызовите техника!" : "")
                .build()
        ));
        
        
        
        
        
        


        
        contents.set(2, ClickableItem.of(new ItemBuilder(TM.control )
            .name("§6Управление")
            .lore("")
            .lore(turret.disabled ? "§7ЛКМ - §2включить" : "§7ПКМ - §4выключить")
            .lore("")
            .lore("§7Клав. Q - §сразобрать")
            .lore("")
            .build(), e -> {

            switch (e.getClick()) {
                case DROP:
                    p.closeInventory();
                    p.performCommand("f destroy "+turret.type+" "+turret.id);//Turr.destroyStructure(claim, true, false);
                    return;
                case LEFT:
                    if (turret.disabled) {
                        TM.setEnabled(turret);
                        reopen(p, contents);
                        return;
                    }
                    break;
                case RIGHT:
                    if (!turret.disabled) {
                        TM.setDisabled(turret);
                        reopen(p, contents);
                        return;
                    }
                    break;
            }

            FM.soundDeny(p);

        }));            
        
        
        
        
        if (turret.disabled) {
            
            contents.set(4, ClickableItem.empty( new ItemBuilder(TM.substance)
                    .name("§8Питание")
                    .lore("")
                    .lore("§8Турель выключена")
                    .lore("§8Субстанция клана:")
                    .lore("§8"+f.getSubstance())
                    .lore("")
                    .lore("§8Расход субстанции")
                    .lore("§8на каждое действие:")
                    .lore("§8"+turret.substRate)
                    .lore("")
                    .build()
            ));
            contents.set(0, ClickableItem.empty( new ItemBuilder(TM.settings)
                    .name("§8Настройки")
                    .lore("")
                    .lore("§8Турель выключена")
                    .lore("")
                    .build()
            ));
            contents.set(1, ClickableItem.empty( new ItemBuilder(TM.upgrade)
                    .name("§8Улучшения")
                    .lore("")
                    .lore("§8Турель выключена")
                    .lore("")
                    .build()
            ));
            
        } else {
            
            contents.set(4, ClickableItem.empty( new ItemBuilder(TM.substance)
                    .name("§3Питание")
                    .lore("")
                    .lore("§7Субстанция клана:")
                    .lore("§f"+f.getSubstance())
                    .lore("")
                    .lore("§7Расход субстанции")
                    .lore("§7на каждое действие:")
                    .lore("§e"+turret.substRate)
                    .lore("")
                    .build()
            ));

            contents.set(0, ClickableItem.of(new ItemBuilder(TM.settings )
                .name("§bНастройки")
                .lore("")
                .lore("§7Турель реагирует:")
                .lore(turret.actionPrimary?"§2• §7На главную цель":"§4• §8§mглавную цель")
                .lore(turret.actionWildernes?"§2• §7На дикарей":"§4• §8§mНа дикарей")
                .lore(turret.actionOther?"§2• §7На остальных":"§4• §8§mНа остальных")
                .lore(turret.actionMobs?"§2• §7На мобов":"§4• §8§mНа мобов")
                .lore("")
                .lore("§а* §7Главная цель - ")
                .lore("§7враги для атакующих,")
                .lore("§7вы и ваши союзники")
                .lore("§7для помогающих.")
                .lore("")
                .lore("§а* §7Мобы - ")
                .lore("§монстры для атакующих,")
                .lore("§7добрые для помогающих.")
                .lore("")
                .build(), e -> {

                switch (e.getClick()) {
                    case LEFT:
                        SmartInventory.builder()
                        .type(InventoryType.HOPPER)
                        .id("TurretSettings"+p.getName()) 
                        .provider(new TurretSettings(turret))
                        .title("Настройки турели")
                        .build()
                        .open(p);
                        return;
                }

                FM.soundDeny(p);

            })); 
            
            
            
            
            if (turret.level>=TM.getMaxLevel(turret.type)) {
                
                contents.set(1, ClickableItem.empty( new ItemBuilder(TM.upgrade)
                    .name("§8Улучшения")
                    .lore("")
                    .lore("§aМаксимальный уровень")
                    .lore("§7•§2Защита: §6"+current.shield)
                    .lore("§7•§2Цели: §6"+current.target)
                    .lore("§7•§2Дальность: §6"+current.radius)
                    .lore("§7•§2Сила: §6"+current.power)
                    .lore("§7•§2Перезаряд: §6"+current.recharge)
                    .lore("§7•§2Расход субстанции: §6"+current.substRate)
                    .lore("")
                    .build()
                ));
                
            } else if (turret.level>=turret.getFaction().getScienceLevel(Science.Турели)) {
                
                contents.set(1, ClickableItem.empty( new ItemBuilder(TM.upgrade)
                    .name("§8Улучшения")
                    .lore("")
                    .lore("§5Достигите новый урвоень")
                    .lore("§5в науке Турели,")
                    .lore("§5чтобы продолжть")
                    .lore("§5улучшения.")
                    .lore("")
                    .build()
                ));
                
            } else {
                
                final Specific next = TM.getSpecific(turret.type, turret.level+1);
                
                if (!turret.getFaction().hasSubstantion(next.upgradePrice)) {
                
                    contents.set(1, ClickableItem.empty( new ItemBuilder(TM.upgrade)
                        .name("§dУлучшить §6"+TM.getLevelLogo(turret.level)+" §7➔ §e"+TM.getLevelLogo(turret.level+1))
                        .lore("")
                        .lore("§7• §2Защита: §6"+current.shield+" §7➔ §e"+next.shield)
                        .lore("§7• §2Цели: §6"+current.target+" §7➔ §e"+next.target)
                        .lore("§7• §2Дальность: §6"+current.radius+" §7➔ §e"+next.radius)
                        .lore("§7• §2Сила: §6"+current.power+" §7➔ §e"+next.power)
                        .lore("§7• §2Перезаряд: §6"+current.recharge+" §7➔ §e"+next.recharge)
                        .lore("§7• §2Расход субстанции: §6"+current.substRate+" §7➔ §e"+next.substRate)
                        .lore("")
                        .lore("§cТребуется субстанции : §b"+next.upgradePrice)
                        .lore("")
                        .lore("")
                        .build()
                    ));

                } else {
                    
                    contents.set(1, ClickableItem.of(new ItemBuilder(TM.upgrade )
                        .name("§dУлучшить §6"+TM.getLevelLogo(turret.level)+" §7➔ §e"+TM.getLevelLogo(turret.level+1))
                        .lore("")
                        .lore("§7• §2Защита: §6"+current.shield+" §7➔ §e"+next.shield)
                        .lore("§7• §2Цели: §6"+current.target+" §7➔ §e"+next.target)
                        .lore("§7• §2Дальность: §6"+current.radius+" §7➔ §e"+next.radius)
                        .lore("§7• §2Сила: §6"+current.power+" §7➔ §e"+next.power)
                        .lore("§7• §2Перезаряд: §6"+current.recharge+" §7➔ §e"+next.recharge)
                        .lore("§7• §2Расход субстанции: §6"+current.substRate+" §7➔ §e"+next.substRate)
                        .lore("")
                        .lore("§7Требуется субстанции : §b"+next.upgradePrice)
                        .lore("")
                        .lore("§7ЛКМ §a- улучшить")
                        .lore("")
                        .build(), e -> {

                            if (turret==null 
                                    || turret.getFaction()==null
                                    || turret.level>=TM.getMaxLevel(turret.type) 
                                    ||!turret.getFaction().hasSubstantion(next.upgradePrice)) {
                                FM.soundDeny(p);
                                reopen(p, contents);
                                return;
                            }
                            
                            switch (e.getClick()) {
                                case LEFT:
                                    turret.getFaction().useSubstance(next.upgradePrice);
                                    turret.getFaction().save(DbField.econ);
                                    turret.setSpecific(next);
                                    DbEngine.saveTurret(turret);
                                    Design.upgrade(turret.getHeadLocation(), turret.type, turret.level);
                                    //TM.setSkin(turret);
                                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_USE, 1, 1);
                                    reopen(p, contents);
                                    return;
                            }

                            FM.soundDeny(p);

                    })); 
                }

            }
            
        }
        
        

        
        
        
       // contents.set(4, ClickableItem.of( new ItemBuilder(Material.OAK_DOOR).name( "закрыть").build(), e -> 
      //      p.closeInventory()
      //  ));
        

        

        


        
        

    }
    
    
    
    
    
    
    
    
    
    
}
